import { streamTurn } from './providers.js';
import { TOOL_NAME, clampTimeoutSec, redactSecrets } from './tool.js';
import { createTypewriterMessage, createCodeBlock } from './render.js';
import { getConfig } from './settings.js';
import { initSettings } from './settings-ui.js';
import { Transcript } from './transcript.js';
import { InputHistory } from './input-history.js';

const $ = (id) => document.getElementById(id);
const logOutput = $('logOutput');
const agentForm = $('agentForm');
const userInput = $('userInput');
const sendBtn = $('sendBtn');
const stopBtn = $('stopBtn');
const exportBtn = $('exportBtn');
const clearBtn = $('clearBtn');
const statusEl = $('status');

const MAX_OUTPUT_CHARS = 4000; // cap what we feed back to the model
const RISKY = /\b(rm\s+-\w*[rf]|sudo|mkfs|dd\s+if=|chmod\s+-R|chown\s+-R|shutdown|reboot|kill\s+-9)\b|\|\s*(ba)?sh\b|>\s*\/dev\//i;
const STATUS = { idle: 'READY', stream: 'STREAMING', wait: 'AWAITING APPROVAL', exec: 'EXECUTING' };
const STOPPED = '[stopped by user]';

const history = []; // provider-neutral model turns
const transcript = new Transcript(); // what the user saw (for export)
const stats = { commands: 0, redactions: 0 };
const bridge = { token: null, cwd: '', online: false };
const inputHistory = new InputHistory({ storage: (() => { try { return window.sessionStorage; } catch { return null; } })() });
let controller = null;

const settingsUi = initSettings({ onChange: () => renderStatusBar(), onExportJson: () => exportSession('json') });

const clip = (s) => (s.length > MAX_OUTPUT_CHARS ? `${s.slice(0, MAX_OUTPUT_CHARS)}\n…[truncated]` : s);
const scrollDown = () => { logOutput.scrollTop = logOutput.scrollHeight; };
const isAbort = (err) => err?.name === 'AbortError';
const shortenPath = (p, max = 48) => (p.length <= max ? p : `…${p.slice(-(max - 1))}`);

/* ---------- Status bar ---------- */
function setStatus(state) {
  statusEl.dataset.state = state;
  statusEl.textContent = STATUS[state];
}

function renderStatusBar() {
  const cfg = getConfig();
  $('sbBridge').dataset.state = bridge.online ? 'ok' : 'err';
  $('sbBridge').textContent = bridge.online ? 'bridge online' : 'bridge offline';
  $('sbCwd').textContent = bridge.cwd ? shortenPath(bridge.cwd) : '—';
  $('sbCwd').parentElement.title = bridge.cwd || 'Working directory';
  $('sbCmds').textContent = `${stats.commands} cmd${stats.commands === 1 ? '' : 's'}`;
  $('sbTimeout').textContent = `timeout ${cfg.timeoutSec}s`;
  $('sbRedact').hidden = stats.redactions === 0;
  $('sbRedact').textContent = `${stats.redactions} redacted`;
}

function setRunning(running) {
  sendBtn.disabled = running; // also blocks Enter-key submits while running
  sendBtn.hidden = running;
  stopBtn.hidden = !running;
  clearBtn.disabled = running;
}

/* ---------- Log rendering ---------- */
function mount(node) {
  logOutput.append(node);
  scrollDown();
  return node;
}

function appendUser(text) {
  const div = document.createElement('div');
  div.className = 'msg msg-user';
  div.textContent = text;
  mount(div);
  transcript.add('user', { text });
}

function appendNotice(text, kind = 'warn', record = true) {
  const div = document.createElement('div');
  div.className = `msg-sys is-${kind}`;
  div.textContent = text;
  mount(div);
  if (record) transcript.add('notice', { text, kind });
}

const chip = (text, cls = '') => {
  const s = document.createElement('span');
  s.className = `meta-chip ${cls}`.trim();
  s.textContent = text;
  return s;
};

function appendToolOutput({ exitCode, output, cwd, redactions }) {
  const wrap = document.createElement('div');
  wrap.className = 'msg msg-tool';
  const exit = chip(`exit ${exitCode}`, exitCode === 0 ? 'is-ok' : 'is-warn');
  wrap.append(exit, chip(shortenPath(cwd ?? '', 40)));
  if (redactions) wrap.append(chip(`${redactions} secret${redactions === 1 ? '' : 's'} masked`, 'is-warn'));
  wrap.append(createCodeBlock('output', output).root);
  mount(wrap);
}

// Human-in-the-loop gate: resolves only on APPROVE, DENY, or Stop
function requestCommandPermission({ command, reason, timeoutSec, cwd }, signal) {
  return new Promise((resolve) => {
    const risky = RISKY.test(command);
    const card = document.createElement('div');
    card.className = `perm-card${risky ? ' is-risky' : ''}`;

    const title = document.createElement('div');
    title.className = 'perm-title';
    title.textContent = `${risky ? 'High risk · ' : ''}Permission required — ${reason}`;

    const meta = document.createElement('div');
    meta.className = 'perm-meta';
    meta.textContent = `${cwd || '(cwd pending)'} · timeout ${timeoutSec}s`;

    const actions = document.createElement('div');
    actions.className = 'perm-actions';
    const mk = (cls, label) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = cls;
      b.textContent = label;
      return b;
    };
    const approveBtn = mk('btn-approve', 'Approve & run');
    const denyBtn = mk('btn-deny', 'Deny');

    let settled = false;
    const finalize = (approved, label) => {
      if (settled) return;
      settled = true;
      signal.removeEventListener('abort', onAbort);
      card.classList.add(approved ? 'is-approved' : 'is-denied');
      title.textContent = label;
      actions.remove();
      resolve(approved);
    };
    const onAbort = () => finalize(false, 'Cancelled');
    signal.addEventListener('abort', onAbort, { once: true });
    approveBtn.addEventListener('click', () => finalize(true, 'Approved'), { once: true });
    denyBtn.addEventListener('click', () => finalize(false, 'Denied by user'), { once: true });

    actions.append(approveBtn, denyBtn);
    card.append(title, meta, createCodeBlock('bash', command).root, actions);
    mount(card);
  });
}

/* ---------- Bridge ---------- */
async function ensureSession(force = false) {
  if (bridge.token && !force) return;
  try {
    const res = await fetch('/api/session');
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const s = await res.json();
    Object.assign(bridge, { token: s.token, cwd: s.cwd, online: true });
  } catch (err) {
    Object.assign(bridge, { token: null, online: false });
    throw new Error(`Bridge unreachable (${err.message}) — is server.mjs running?`);
  } finally {
    renderStatusBar();
  }
}

async function runLocalCommand(command, timeoutSec, signal) {
  for (let attempt = 0; attempt < 2; attempt++) {
    await ensureSession();
    let res;
    try {
      res = await fetch('/api/exec', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Nexus-Token': bridge.token },
        body: JSON.stringify({ command, timeoutMs: timeoutSec * 1000 }),
        signal
      });
    } catch (err) {
      if (!isAbort(err)) { bridge.online = false; renderStatusBar(); }
      throw err;
    }
    if (res.status === 401 && attempt === 0) { bridge.token = null; continue; } // bridge restarted / session evicted
    if (res.status === 409) throw new Error('Bridge is still busy with the previous command.');
    if (!res.ok) throw new Error(`Bridge error: HTTP ${res.status}`);
    const out = await res.json();
    if (typeof out.cwd === 'string') bridge.cwd = out.cwd;
    return out;
  }
  throw new Error('Bridge session expired.');
}

const combineOutput = ({ stdout, stderr }) =>
  [stdout, stderr && (stdout ? `[stderr]\n${stderr}` : stderr)].filter(Boolean).join('\n') || '(no output)';

async function runCall({ id, name, args }, cfg, signal) {
  const done = (result) => ({ id, name, result });
  if (signal.aborted) return done({ error: 'Cancelled by user.' });
  if (name !== TOOL_NAME) return done({ error: `Unknown tool: ${name}` });

  const command = String(args?.command ?? '').trim();
  if (!command) return done({ error: 'Empty command.' });
  const timeoutSec = clampTimeoutSec(args.timeout_seconds, cfg.timeoutSec);
  const reason = args.reason || 'Run shell command';

  setStatus('wait');
  const approved = await requestCommandPermission({ command, reason, timeoutSec, cwd: bridge.cwd }, signal);
  transcript.add('command', { command, reason, timeoutSec, cwd: bridge.cwd, status: approved ? 'approved' : signal.aborted ? 'cancelled' : 'denied' });
  if (!approved) {
    return done({ error: signal.aborted ? 'Cancelled by user.' : 'User explicitly denied permission to execute this command.' });
  }

  setStatus('exec');
  const r = await runLocalCommand(command, timeoutSec, signal);
  const red = redactSecrets(clip(combineOutput(r)), [cfg.apiKey]); // server already masked; this also masks your own key
  const redactions = (r.redactions ?? 0) + red.count;
  stats.commands++;
  stats.redactions += redactions;

  appendToolOutput({ exitCode: r.exitCode, output: red.text, cwd: r.cwd, redactions });
  transcript.add('output', { exitCode: r.exitCode, output: red.text, cwd: r.cwd });
  renderStatusBar();
  return done({ exitCode: r.exitCode, output: red.text, cwd: r.cwd });
}

/* ---------- Agent loop ---------- */
async function runAgentLoop(prompt, cfg, signal) {
  history.push({ role: 'user', text: prompt });

  for (let step = 0; step < cfg.maxSteps; step++) {
    const msg = createTypewriterMessage(logOutput, { onTick: scrollDown });
    signal.addEventListener('abort', () => msg.flush(), { once: true }); // skip the typewriter on Stop
    setStatus('stream');

    let turn;
    try {
      turn = await streamTurn(cfg.provider, {
        apiKey: cfg.apiKey,
        model: cfg.model,
        maxTokens: cfg.maxTokens,
        history,
        onText: msg.push,
        signal
      });
    } catch (err) {
      const partial = msg.text;
      msg.flush();
      if (partial) transcript.add('agent', { text: partial });
      // keep roles alternating so the next prompt stays valid for every provider
      if (isAbort(err)) {
        history.push({ role: 'agent', provider: cfg.provider, text: partial ? `${partial}\n${STOPPED}` : STOPPED, calls: [], raw: null });
      }
      throw err;
    }
    await msg.finish();
    history.push({ role: 'agent', provider: cfg.provider, ...turn });
    if (turn.text) transcript.add('agent', { text: turn.text });

    if (!turn.calls.length) {
      if (!turn.text) appendNotice('(empty response)');
      return;
    }

    const results = [];
    try {
      for (const call of turn.calls) results.push(await runCall(call, cfg, signal));
    } finally {
      // every tool call needs a result, even when cancelled, or the next request is rejected
      for (const call of turn.calls.slice(results.length)) {
        results.push({ id: call.id, name: call.name, result: { error: 'Cancelled by user.' } });
      }
      history.push({ role: 'tool', provider: cfg.provider, results });
    }
  }
  appendNotice('Step limit reached. Send another directive to continue (limit is in Settings).');
}

/* ---------- Session export / clear ---------- */
function download(name, mime, content) {
  const url = URL.createObjectURL(new Blob([content], { type: mime }));
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function exportSession(format = 'md') {
  if (!transcript.size) { appendNotice('Nothing to export yet.', 'info', false); return; }
  const { label, model } = getConfig();
  const meta = { provider: label, model }; // never keys
  const stamp = new Date().toISOString().replace(/[-:]/g, '').replace('T', '-').slice(0, 15);
  if (format === 'json') download(`nexus-session-${stamp}.json`, 'application/json', transcript.toJSON(meta));
  else download(`nexus-session-${stamp}.md`, 'text/markdown', transcript.toMarkdown(meta));
}

async function clearSession() {
  history.length = 0;
  transcript.clear();
  Object.assign(stats, { commands: 0, redactions: 0 });
  logOutput.replaceChildren();
  try {
    await ensureSession(true); // fresh shell session = cwd back to the start directory
    appendNotice(`Session cleared. New shell session in ${bridge.cwd}.`, 'info', false);
  } catch {
    appendNotice('Session cleared.', 'info', false);
  }
  renderStatusBar();
}

let confirmTimer = 0;
const setConfirm = (on) => {
  clearTimeout(confirmTimer);
  clearBtn.classList.toggle('is-confirm', on);
  clearBtn.querySelector('.confirm-label').hidden = !on;
  if (on) confirmTimer = setTimeout(() => setConfirm(false), 3000);
};

clearBtn.addEventListener('click', () => {
  if (controller) return;
  if (!clearBtn.classList.contains('is-confirm')) return setConfirm(true); // two-step confirm
  setConfirm(false);
  clearSession();
});
exportBtn.addEventListener('click', () => exportSession('md'));

/* ---------- Prompt box: submit, Up/Down history, Stop ---------- */
const setInput = (value) => {
  userInput.value = value;
  userInput.setSelectionRange(value.length, value.length);
};

userInput.addEventListener('keydown', (e) => {
  if (e.isComposing || e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
  if (e.key !== 'ArrowUp' && e.key !== 'ArrowDown') return;
  const value = e.key === 'ArrowUp' ? inputHistory.prev(userInput.value) : inputHistory.next();
  if (value === null) return;
  e.preventDefault();
  setInput(value);
});

agentForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const prompt = userInput.value.trim();
  if (!prompt) return;

  const cfg = getConfig();
  if (!cfg.apiKey || !cfg.model) {
    settingsUi.open('Add an API key and choose a model to start.');
    return;
  }

  inputHistory.push(prompt);
  userInput.value = '';
  controller = new AbortController();
  setRunning(true);
  appendUser(prompt);

  try {
    await runAgentLoop(prompt, cfg, controller.signal);
  } catch (err) {
    if (isAbort(err)) appendNotice('Stopped.');
    else appendNotice(`Fault: ${err.message}`, 'error');
  } finally {
    controller = null;
    setRunning(false);
    setStatus('idle');
    renderStatusBar();
    userInput.focus();
  }
});

stopBtn.addEventListener('click', () => controller?.abort());
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && controller && !$('settingsDialog').open) controller.abort();
});

setStatus('idle');
renderStatusBar();
ensureSession().catch(() => {}); // show bridge + cwd in the status bar right away
