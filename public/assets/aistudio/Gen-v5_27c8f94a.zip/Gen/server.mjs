// server.mjs — local bridge: static UI + per-session command runner.
// Env: PORT (8080) · NEXUS_CWD (start dir) · NEXUS_TIMEOUT_MS (10000) · NEXUS_MAX_TIMEOUT_MS (120000)
import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { redactSecrets } from './tool.js';

const PORT = Number(process.env.PORT) || 8080;
const ROOT = path.dirname(fileURLToPath(import.meta.url));
const HOSTS = new Set([`localhost:${PORT}`, `127.0.0.1:${PORT}`]);

const envMs = (name, fallback) => {
  const n = Number(process.env[name]);
  return Number.isFinite(n) && n >= 1000 ? Math.round(n) : fallback;
};
const DEFAULT_TIMEOUT_MS = envMs('NEXUS_TIMEOUT_MS', 10_000);
const MAX_TIMEOUT_MS = Math.max(DEFAULT_TIMEOUT_MS, envMs('NEXUS_MAX_TIMEOUT_MS', 120_000));
const clampMs = (v) => (Number.isFinite(Number(v)) && v !== null && v !== '' ? Math.min(MAX_TIMEOUT_MS, Math.max(1000, Math.round(Number(v)))) : DEFAULT_TIMEOUT_MS);

const MAX_OUTPUT = 1024 * 1024;
const MAX_SESSIONS = 50;
const SIGNALS = os.constants.signals;

const isDir = async (p) => { try { return (await fs.stat(p)).isDirectory(); } catch { return false; } };
const START_CWD = (process.env.NEXUS_CWD && (await isDir(process.env.NEXUS_CWD)) && path.resolve(process.env.NEXUS_CWD)) || process.cwd();

/* ---------- Sessions: one token = one tab = one working directory ---------- */
const sessions = new Map(); // token -> { cwd, busy }
const TOKEN_RE = /^[a-f0-9]{64}$/;

function createSession() {
  if (sessions.size >= MAX_SESSIONS) sessions.delete(sessions.keys().next().value); // evict oldest
  const token = crypto.randomBytes(32).toString('hex');
  const session = { cwd: START_CWD, busy: false };
  sessions.set(token, session);
  return { token, session };
}
const findSession = (token) => (typeof token === 'string' && TOKEN_RE.test(token) ? sessions.get(token) : undefined);

/* ---------- Command runner ---------- */
// Own process group so Stop/timeout kills the whole tree. fd 3 reports the final $PWD (EXIT trap
// also fires on `exit N`), which is how `cd` persists across commands.
const runCommand = ({ command, cwd, timeoutMs, signal }) => new Promise((resolve) => {
  const script = `trap 'printf %s "$PWD" >&3' EXIT\n${command}`;
  const child = spawn('/bin/bash', ['-c', script], { cwd, detached: true, stdio: ['ignore', 'pipe', 'pipe', 'pipe'] });

  let stdout = '';
  let stderr = '';
  let cwdOut = '';
  let note = '';
  let exitCode = 1;
  let settled = false;

  const killTree = () => { try { process.kill(-child.pid, 'SIGKILL'); } catch { /* already gone */ } };
  const timer = setTimeout(() => { note = `\n[timed out after ${timeoutMs / 1000}s]`; killTree(); }, timeoutMs);
  const onAbort = () => { note = '\n[cancelled]'; killTree(); };
  signal.addEventListener('abort', onAbort, { once: true });

  const finish = () => {
    if (settled) return;
    settled = true;
    clearTimeout(timer);
    signal.removeEventListener('abort', onAbort);
    for (const s of [child.stdout, child.stderr, child.stdio[3]]) s?.destroy(); // don't wait on backgrounded children
    resolve({ stdout: stdout.trim(), stderr: (stderr + note).trim(), exitCode, cwd: cwdOut });
  };

  child.stdout.setEncoding('utf8').on('data', (d) => { if (stdout.length < MAX_OUTPUT) stdout += d; });
  child.stderr.setEncoding('utf8').on('data', (d) => { if (stderr.length < MAX_OUTPUT) stderr += d; });
  child.stdio[3].setEncoding('utf8').on('data', (d) => { if (cwdOut.length < 4096) cwdOut += d; });
  child.on('error', (err) => { stderr += err.message; finish(); });
  child.on('exit', (code, sig) => { exitCode = code ?? 128 + (SIGNALS[sig] ?? 0); setTimeout(finish, 100); }); // short grace to drain pipes
  child.on('close', finish);
});

/* ---------- HTTP helpers ---------- */
const JS = 'text/javascript; charset=utf-8';
// Whitelist: nothing else on disk (incl. this file) is ever served
const FILES = new Map([
  ['index.html', 'text/html; charset=utf-8'],
  ['style.css', 'text/css; charset=utf-8'],
  ...['script.js', 'render.js', 'tool.js', 'sse.js', 'providers.js', 'provider-gemini.js', 'provider-anthropic.js',
    'provider-openai.js', 'settings.js', 'settings-ui.js', 'transcript.js', 'input-history.js'].map((f) => [f, JS])
]);

const SEC = {
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'no-referrer',
  'X-Frame-Options': 'DENY',
  'Cache-Control': 'no-store'
};

const sendJson = (res, code, obj) => {
  res.writeHead(code, { 'Content-Type': 'application/json', ...SEC });
  res.end(JSON.stringify(obj));
};

const readBody = async (req, limit = 8192) => {
  const chunks = [];
  let size = 0;
  for await (const c of req) {
    size += c.length;
    if (size > limit) throw new Error('Payload too large');
    chunks.push(c);
  }
  return Buffer.concat(chunks).toString('utf8');
};

// Same-origin only: blocks cross-site requests (CSRF) and DNS rebinding
const sameOrigin = (req) => {
  const site = req.headers['sec-fetch-site'];
  if (site && site !== 'same-origin' && site !== 'none') return false;
  const origin = req.headers.origin;
  return !origin || HOSTS.has(origin.replace(/^http:\/\//, ''));
};

/* ---------- Server ---------- */
const server = http.createServer(async (req, res) => {
  if (!HOSTS.has(req.headers.host ?? '') || !sameOrigin(req)) return sendJson(res, 403, { error: 'Forbidden' });
  const { pathname } = new URL(req.url, `http://${req.headers.host}`);

  if (req.method === 'GET' && pathname === '/api/session') {
    const { token, session } = createSession();
    return sendJson(res, 200, { token, cwd: session.cwd, timeoutMs: DEFAULT_TIMEOUT_MS, maxTimeoutMs: MAX_TIMEOUT_MS });
  }

  if (req.method === 'POST' && pathname === '/api/exec') {
    const session = findSession(req.headers['x-nexus-token']);
    if (!session) return sendJson(res, 401, { error: 'Bad token' });
    if (!String(req.headers['content-type'] ?? '').startsWith('application/json')) return sendJson(res, 415, { error: 'JSON only' });
    if (session.busy) return sendJson(res, 409, { error: 'A command is already running in this session.' });

    session.busy = true;
    try {
      const { command, timeoutMs } = JSON.parse(await readBody(req));
      if (typeof command !== 'string' || !command.trim() || command.length > 2000) {
        return sendJson(res, 400, { error: 'Invalid command payload.' });
      }

      if (!(await isDir(session.cwd))) session.cwd = START_CWD; // directory was deleted underneath us

      const ac = new AbortController(); // client pressed Stop -> connection closes -> kill the tree
      res.on('close', () => { if (!res.writableEnded) ac.abort(); });
      const effectiveMs = clampMs(timeoutMs);
      const out = await runCommand({ command, cwd: session.cwd, timeoutMs: effectiveMs, signal: ac.signal });

      if (out.cwd && path.isAbsolute(out.cwd) && (await isDir(out.cwd))) session.cwd = out.cwd;
      if (res.destroyed) return;

      const so = redactSecrets(out.stdout);
      const se = redactSecrets(out.stderr);
      return sendJson(res, 200, {
        stdout: so.text,
        stderr: se.text,
        exitCode: out.exitCode,
        cwd: session.cwd,
        timeoutMs: effectiveMs,
        redactions: so.count + se.count
      });
    } catch {
      return sendJson(res, 400, { error: 'Bad request.' });
    } finally {
      session.busy = false;
    }
  }

  const name = pathname === '/' ? 'index.html' : pathname.slice(1);
  if (req.method !== 'GET' || !FILES.has(name)) return sendJson(res, 404, { error: 'Not found' });
  try {
    const content = await fs.readFile(path.join(ROOT, name));
    res.writeHead(200, { 'Content-Type': FILES.get(name), ...SEC });
    res.end(content);
  } catch {
    sendJson(res, 404, { error: 'Not found' });
  }
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`[NEXUS_BRIDGE] http://localhost:${PORT}`);
  console.log(`[NEXUS_BRIDGE] cwd=${START_CWD} timeout=${DEFAULT_TIMEOUT_MS}ms max=${MAX_TIMEOUT_MS}ms`);
});
