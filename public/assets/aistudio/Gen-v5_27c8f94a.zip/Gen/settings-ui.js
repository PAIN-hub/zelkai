// settings-ui.js — wires the <dialog> to settings state.
import { PROVIDERS, listModels } from './providers.js';
import { getState, commit, clearKeys, getConfig } from './settings.js';

export function initSettings({ onChange, onExportJson } = {}) {
  const $ = (id) => document.getElementById(id);
  const dlg = $('settingsDialog');
  const form = $('settingsForm');
  const providerSel = $('setProvider');
  const keyInput = $('setKey');
  const modelInput = $('setModel');
  const modelList = $('modelList');
  const fetchBtn = $('fetchModels');
  const fetchMsg = $('fetchMsg');
  const maxTokens = $('setMaxTokens');
  const maxSteps = $('setMaxSteps');
  const timeoutInput = $('setTimeoutSec');
  const remember = $('setRemember');
  const notice = $('settingsNotice');
  const chip = $('modelChip');

  let draft = getState();
  const modelCache = {};
  let fetchCtl = null;

  for (const [id, p] of Object.entries(PROVIDERS)) {
    const o = document.createElement('option');
    o.value = id;
    o.textContent = p.label;
    providerSel.append(o);
  }

  const fillList = (list) => modelList.replaceChildren(...list.map((value) => Object.assign(document.createElement('option'), { value })));

  const showFields = () => {
    const p = draft.settings.provider;
    providerSel.value = p;
    keyInput.value = draft.keys[p];
    keyInput.placeholder = PROVIDERS[p].keyHint;
    modelInput.value = draft.settings.models[p];
    fillList(modelCache[p] ?? []);
    fetchMsg.textContent = '';
    maxTokens.value = draft.settings.maxTokens;
    maxSteps.value = draft.settings.maxSteps;
    timeoutInput.value = draft.settings.timeoutSec;
    remember.checked = draft.settings.remember;
  };

  const captureFields = () => {
    const p = draft.settings.provider; // still the previous provider while switching
    draft.keys[p] = keyInput.value.trim();
    draft.settings.models[p] = modelInput.value.trim();
    draft.settings.maxTokens = Number(maxTokens.value);
    draft.settings.maxSteps = Number(maxSteps.value);
    draft.settings.timeoutSec = Number(timeoutInput.value);
    draft.settings.remember = remember.checked;
  };

  const updateChip = () => {
    const c = getConfig();
    chip.textContent = `${c.label} · ${c.model || 'select model'}`;
    chip.title = 'Open settings';
  };

  const open = (message = '') => {
    draft = getState();
    showFields();
    notice.textContent = message;
    notice.hidden = !message;
    dlg.showModal();
  };

  providerSel.addEventListener('change', () => {
    fetchCtl?.abort();
    captureFields();
    draft.settings.provider = providerSel.value;
    showFields();
  });

  fetchBtn.addEventListener('click', async () => {
    const p = providerSel.value;
    const apiKey = keyInput.value.trim();
    if (!apiKey) { fetchMsg.textContent = 'Enter an API key first.'; return; }
    fetchCtl?.abort();
    fetchCtl = new AbortController();
    fetchBtn.disabled = true;
    fetchMsg.textContent = 'Loading…';
    try {
      const list = await listModels(p, { apiKey, signal: fetchCtl.signal });
      modelCache[p] = list;
      if (providerSel.value === p) {
        fillList(list);
        fetchMsg.textContent = `${list.length} models — pick one or type an ID.`;
      }
    } catch (err) {
      if (err.name !== 'AbortError') fetchMsg.textContent = `Failed: ${err.message}`;
    } finally {
      fetchBtn.disabled = false;
    }
  });

  $('clearKeys').addEventListener('click', () => {
    clearKeys();
    draft.keys = getState().keys;
    keyInput.value = '';
    fetchMsg.textContent = 'Saved keys cleared.';
    updateChip();
  });

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    captureFields();
    commit(draft);
    updateChip();
    onChange?.(getConfig());
    dlg.close();
  });

  $('exportJson').addEventListener('click', () => onExportJson?.());
  $('settingsCancel').addEventListener('click', () => dlg.close());
  dlg.addEventListener('click', (e) => { if (e.target === dlg) dlg.close(); }); // backdrop click
  dlg.addEventListener('close', () => fetchCtl?.abort());
  chip.addEventListener('click', () => open());
  $('settingsBtn').addEventListener('click', () => open());

  updateChip();
  return { open };
}
