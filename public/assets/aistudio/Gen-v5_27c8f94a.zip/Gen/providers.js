// providers.js — registry. Each adapter exports streamTurn() and listModels().
import * as gemini from './provider-gemini.js';
import * as anthropic from './provider-anthropic.js';
import * as openai from './provider-openai.js';

export const PROVIDERS = {
  gemini: { label: 'Gemini', keyHint: 'Gemini API key', adapter: gemini },
  anthropic: { label: 'Claude', keyHint: 'Anthropic API key (sk-ant-…)', adapter: anthropic },
  openai: { label: 'OpenAI / Codex', keyHint: 'OpenAI API key (sk-…)', adapter: openai }
};

const adapterOf = (id) => {
  if (!Object.hasOwn(PROVIDERS, id)) throw new Error(`Unknown provider: ${id}`);
  return PROVIDERS[id].adapter;
};

export const streamTurn = (id, opts) => adapterOf(id).streamTurn(opts);
export const listModels = (id, opts) => adapterOf(id).listModels(opts);
