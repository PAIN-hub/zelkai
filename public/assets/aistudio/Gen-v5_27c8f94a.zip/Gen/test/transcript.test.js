import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Transcript, fence } from '../transcript.js';

const sample = () => {
  const t = new Transcript();
  t.add('user', { text: 'show env, my key is sk-abcdefghijklmnopqrstuvwx' });
  t.add('agent', { text: 'Running it.' });
  t.add('command', { command: 'echo "```"; env', reason: 'inspect', status: 'approved', cwd: '/tmp', timeoutSec: 10 });
  t.add('output', { exitCode: 0, output: 'API_TOKEN=abcd1234efgh\n```\nend', cwd: '/tmp' });
  t.add('notice', { text: 'Stopped.', kind: 'warn' });
  return t;
};

test('fence is always longer than any backtick run inside the content', () => {
  assert.equal(fence('plain'), '```');
  assert.equal(fence('a ``` b'), '````');
  assert.equal(fence('`````'), '``````');
});

test('markdown export has every section, safe fences and no secrets', () => {
  const md = sample().toMarkdown({ provider: 'Claude', model: 'claude-x' });
  assert.match(md, /^# Nexus session/);
  assert.match(md, /- Model: Claude · claude-x/);
  for (const h of ['## You', '## Agent', '### Command — approved', '### Output — exit 0 · /tmp']) assert.ok(md.includes(h), h);
  assert.ok(md.includes('````bash'), 'command containing ``` gets a longer fence');
  assert.ok(md.includes('````text'), 'output containing ``` gets a longer fence');
  assert.ok(!md.includes('sk-abcdefghijkl') && !md.includes('abcd1234efgh'), 'secrets redacted');
  assert.match(md, /> Stopped\./);
});

test('json export redacts, keeps metadata and never includes keys', () => {
  const data = JSON.parse(sample().toJSON({ provider: 'Claude', model: 'm' }));
  assert.equal(data.app, 'nexus-shell-agent');
  assert.equal(data.model, 'm');
  assert.equal(data.items.length, 5);
  assert.ok(!JSON.stringify(data).includes('abcdefghijklmnopqrstuvwx'));
  assert.equal(data.items[3].exitCode, 0);
});

test('items() is a copy and clear() empties the log', () => {
  const t = sample();
  t.items()[0].text = 'mutated';
  assert.notEqual(t.items()[0].text, 'mutated');
  assert.equal(t.size, 5);
  t.clear();
  assert.equal(t.size, 0);
  assert.equal(t.toMarkdown().trim(), '# Nexus session\n\n- Exported: ' + t.toMarkdown().match(/Exported: (\S+)/)[1]);
});
