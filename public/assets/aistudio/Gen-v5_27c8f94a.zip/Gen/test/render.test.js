import { test } from 'node:test';
import assert from 'node:assert/strict';
import { parseBlocks } from '../render.js';

test('parseBlocks splits text and fenced code', () => {
  const b = parseBlocks('Hello **x**\n```bash\ndf -h\n```\nDone');
  assert.deepEqual(b.map((x) => [x.type, x.lang, x.text]), [['text', '', 'Hello **x**'], ['code', 'bash', 'df -h'], ['text', '', 'Done']]);
});

test('parseBlocks handles an unclosed fence while streaming', () => {
  const b = parseBlocks('go:\n```py\nprint(1)');
  assert.deepEqual(b.map((x) => [x.type, x.lang, x.text]), [['text', '', 'go:'], ['code', 'py', 'print(1)']]);
});

test('parseBlocks keeps an empty just-opened code block and drops blank text', () => {
  assert.deepEqual(parseBlocks('```js\n').map((x) => [x.type, x.lang, x.text]), [['code', 'js', '']]);
  assert.deepEqual(parseBlocks('\n\n  \n'), []);
});

test('parseBlocks never produces markup — angle brackets stay plain text', () => {
  const [b] = parseBlocks('<img src=x onerror=alert(1)>');
  assert.equal(b.text, '<img src=x onerror=alert(1)>'); // rendered via textContent only
});
