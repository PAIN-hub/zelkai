import { test } from 'node:test';
import assert from 'node:assert/strict';
import { sanitize, getConfig } from '../settings.js';

test('sanitize clamps numbers, rejects unknown providers and trims strings', () => {
  const s = sanitize({ settings: { provider: 'toString', maxTokens: 1e9, maxSteps: 'x', timeoutSec: 9999, models: { openai: ' gpt-x ' } }, keys: { gemini: 5, anthropic: ' k ' } });
  assert.equal(s.settings.provider, 'gemini');
  assert.equal(s.settings.maxTokens, 64000);
  assert.equal(s.settings.maxSteps, 6);
  assert.equal(s.settings.timeoutSec, 120);
  assert.equal(s.settings.models.openai, 'gpt-x');
  assert.equal(s.keys.gemini, '');
  assert.equal(s.keys.anthropic, 'k');
});

test('sanitize defaults on garbage input', () => {
  for (const bad of [undefined, null, 'x', { settings: 5 }]) {
    const s = sanitize(bad);
    assert.equal(s.settings.timeoutSec, 10);
    assert.equal(s.settings.remember, false);
  }
});

test('getConfig works without browser storage (Node)', () => {
  const c = getConfig();
  assert.equal(c.provider, 'gemini');
  assert.equal(c.timeoutSec, 10);
  assert.equal(c.apiKey, '');
});
