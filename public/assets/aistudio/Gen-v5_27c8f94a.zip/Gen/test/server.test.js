// Integration tests: spawns the real bridge on a free port.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import http from 'node:http';
import net from 'node:net';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { setTimeout as sleep } from 'node:timers/promises';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const skip = !fs.existsSync('/bin/bash') && 'needs /bin/bash (Linux/macOS/WSL)';
let proc;
let base;
let port;
let tmp;

const freePort = () => new Promise((resolve) => {
  const s = net.createServer();
  s.listen(0, '127.0.0.1', () => { const { port: p } = s.address(); s.close(() => resolve(p)); });
});
const session = async () => (await fetch(`${base}/api/session`)).json();
const exec = (token, body, init = {}) => fetch(`${base}/api/exec`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Nexus-Token': token }, body: JSON.stringify(body), ...init });
const run = async (token, command, extra = {}) => (await exec(token, { command, ...extra })).json();
const rawGet = (reqPath, headers = {}) => new Promise((resolve, reject) => {
  http.get({ host: '127.0.0.1', port, path: reqPath, headers: { Host: `localhost:${port}`, ...headers } }, (res) => { res.resume(); res.on('end', () => resolve(res.statusCode)); }).on('error', reject);
});

before(async () => {
  if (skip) return;
  tmp = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), 'nexus-')));
  fs.mkdirSync(path.join(tmp, 'sub'));
  port = await freePort();
  base = `http://localhost:${port}`;
  proc = spawn(process.execPath, ['server.mjs'], { cwd: ROOT, env: { ...process.env, PORT: String(port), NEXUS_CWD: tmp, NEXUS_TIMEOUT_MS: '3000', NEXUS_MAX_TIMEOUT_MS: '5000' } });
  await new Promise((resolve, reject) => {
    proc.stdout.on('data', (d) => String(d).includes('[NEXUS_BRIDGE] http') && resolve());
    proc.on('error', reject);
    setTimeout(() => reject(new Error('server did not start')), 8000);
  });
});

after(() => {
  proc?.kill();
  if (tmp) fs.rmSync(tmp, { recursive: true, force: true });
});

test('session endpoint reports cwd and timeout config', { skip }, async () => {
  const s = await session();
  assert.match(s.token, /^[a-f0-9]{64}$/);
  assert.equal(s.cwd, tmp);
  assert.equal(s.timeoutMs, 3000);
  assert.equal(s.maxTimeoutMs, 5000);
});

test('auth: token, content-type and host are enforced', { skip }, async () => {
  assert.equal((await fetch(`${base}/api/exec`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{"command":"id"}' })).status, 401);
  assert.equal((await fetch(`${base}/api/exec`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Nexus-Token': 'a'.repeat(64) }, body: '{"command":"id"}' })).status, 401);
  const { token } = await session();
  assert.equal((await fetch(`${base}/api/exec`, { method: 'POST', headers: { 'Content-Type': 'text/plain', 'X-Nexus-Token': token }, body: '{"command":"id"}' })).status, 415);
  assert.equal((await exec(token, { command: '' })).status, 400);
  assert.equal((await exec(token, { command: 'x'.repeat(2001) })).status, 400);
  assert.equal(await rawGet('/api/session', { Host: 'evil.example' }), 403);
  assert.equal(await rawGet('/', { Origin: 'http://evil.example' }), 403);
  assert.equal(await rawGet('/', { 'Sec-Fetch-Site': 'cross-site' }), 403);
});

test('static files: only the whitelist is served', { skip }, async () => {
  assert.equal((await fetch(`${base}/`)).status, 200);
  assert.match(await (await fetch(`${base}/`)).text(), /Nexus/);
  for (const f of ['tool.js', 'transcript.js', 'input-history.js', 'script.js']) assert.equal((await fetch(`${base}/${f}`)).status, 200, f);
  for (const f of ['server.mjs', 'package.json', 'test/server.test.js']) assert.equal((await fetch(`${base}/${f}`)).status, 404, f);
  assert.equal(await rawGet('/../server.mjs'), 404);
  assert.equal(await rawGet('/..%2fserver.mjs'), 404);
});

test('cwd persists between commands, including after `exit N`', { skip }, async () => {
  const { token } = await session();
  let r = await run(token, 'cd sub && pwd');
  assert.equal(r.stdout, path.join(tmp, 'sub'));
  assert.equal(r.cwd, path.join(tmp, 'sub'));
  r = await run(token, 'pwd');
  assert.equal(r.stdout, path.join(tmp, 'sub'));
  r = await run(token, 'cd ..; exit 3');
  assert.equal(r.exitCode, 3);
  assert.equal(r.cwd, tmp);
  assert.equal((await run(token, 'pwd')).stdout, tmp);
});

test('sessions are isolated from each other', { skip }, async () => {
  const a = await session();
  const b = await session();
  await run(a.token, 'cd sub');
  assert.equal((await run(b.token, 'pwd')).stdout, tmp);
  assert.equal((await run(a.token, 'pwd')).stdout, path.join(tmp, 'sub'));
});

test('a deleted working directory falls back to the start directory', { skip }, async () => {
  const { token } = await session();
  fs.mkdirSync(path.join(tmp, 'gone'));
  await run(token, 'cd gone');
  fs.rmdirSync(path.join(tmp, 'gone'));
  const r = await run(token, 'pwd');
  assert.equal(r.stdout, tmp);
  assert.equal(r.cwd, tmp);
});

test('timeouts are configurable and clamped by the server', { skip }, async () => {
  const { token } = await session();
  assert.equal((await run(token, 'true')).timeoutMs, 3000); // default
  assert.equal((await run(token, 'true', { timeoutMs: 999_999 })).timeoutMs, 5000); // clamped to max
  assert.equal((await run(token, 'true', { timeoutMs: 1 })).timeoutMs, 1000); // clamped to min

  const t0 = Date.now();
  const r = await run(token, 'sleep 10', { timeoutMs: 1000 });
  assert.match(r.stderr, /timed out after 1s/);
  assert.notEqual(r.exitCode, 0);
  assert.ok(Date.now() - t0 < 4000);
});

test('secrets in output are redacted server-side', { skip }, async () => {
  const { token } = await session();
  const r = await run(token, 'echo "API_KEY=supersecretvalue1234"; echo "sk-abcdefghijklmnopqrstuvwx" >&2; echo visible');
  assert.ok(!r.stdout.includes('supersecretvalue1234'));
  assert.ok(!r.stderr.includes('abcdefghijkl'));
  assert.match(r.stdout, /visible/);
  assert.equal(r.redactions, 2);
});

test('stdout and stderr are both returned; background children do not hang the response', { skip }, async () => {
  const { token } = await session();
  let r = await run(token, 'echo out; echo err >&2');
  assert.deepEqual([r.stdout, r.stderr], ['out', 'err']);
  const t0 = Date.now();
  r = await run(token, 'sleep 3 & echo started');
  assert.equal(r.stdout, 'started');
  assert.ok(Date.now() - t0 < 2000);
});

test('busy guard: one command at a time per session', { skip }, async () => {
  const { token } = await session();
  const first = exec(token, { command: 'sleep 1' });
  await sleep(150);
  assert.equal((await exec(token, { command: 'echo x' })).status, 409);
  assert.equal((await first).status, 200);
});

test('Stop: aborting the request kills the command and frees the session', { skip }, async () => {
  const { token } = await session();
  const marker = path.join(tmp, 'marker');
  const ac = new AbortController();
  const pending = exec(token, { command: `sleep 20; touch ${marker}` }, { signal: ac.signal }).catch(() => {});
  await sleep(300);
  ac.abort();
  await pending;
  await sleep(500);
  assert.equal(fs.existsSync(marker), false);
  assert.equal((await run(token, 'echo alive')).stdout, 'alive'); // would be 409 if busy was never cleared
});
