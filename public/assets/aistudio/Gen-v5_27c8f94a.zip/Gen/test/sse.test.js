import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readSSE, ensureOk } from '../sse.js';

const streamOf = (...chunks) => ({ body: new ReadableStream({ start(c) { chunks.forEach((s) => c.enqueue(new TextEncoder().encode(s))); c.close(); } }) });
const collect = async (res) => { const out = []; for await (const e of readSSE(res)) out.push(e); return out; };

test('readSSE parses events split across chunks, CRLF, named events and [DONE]', async () => {
  const res = streamOf('event: a\r\ndata: {"n":1}\r\n\r\ndata: {"n"', ':2}\n\n: comment\n\ndata: [DONE]\n\n', 'data: {"n":3}');
  assert.deepEqual(await collect(res), [{ n: 1 }, { n: 2 }, { n: 3 }]);
});

test('readSSE surfaces malformed JSON as an error', async () => {
  await assert.rejects(collect(streamOf('data: {oops\n\n')));
});

test('ensureOk throws provider error messages', async () => {
  const bad = { ok: false, status: 401, json: async () => ({ error: { message: 'bad key' } }) };
  await assert.rejects(ensureOk(bad), /bad key/);
  const noBody = { ok: false, status: 500, json: async () => { throw new Error('x'); } };
  await assert.rejects(ensureOk(noBody), /HTTP 500/);
  const ok = { ok: true };
  assert.equal(await ensureOk(ok), ok);
});
