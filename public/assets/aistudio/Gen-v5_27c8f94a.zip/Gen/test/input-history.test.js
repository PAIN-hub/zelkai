import { test } from 'node:test';
import assert from 'node:assert/strict';
import { InputHistory } from '../input-history.js';

const memStorage = (init = {}) => { const d = { ...init }; return { getItem: (k) => d[k] ?? null, setItem: (k, v) => { d[k] = v; }, d }; };

test('Up/Down walks history and restores the draft', () => {
  const h = new InputHistory();
  ['one', 'two', 'three'].forEach((x) => h.push(x));
  assert.equal(h.prev('draft'), 'three');
  assert.equal(h.prev('ignored'), 'two');
  assert.equal(h.prev(''), 'one');
  assert.equal(h.prev(''), 'one'); // stays at oldest
  assert.equal(h.next(), 'two');
  assert.equal(h.next(), 'three');
  assert.equal(h.next(), 'draft'); // back to what was being typed
  assert.equal(h.next(), null); // no longer browsing
});

test('empty history returns null; push ignores blanks and consecutive duplicates', () => {
  const h = new InputHistory();
  assert.equal(h.prev('x'), null);
  h.push('  '); h.push('a'); h.push('a'); h.push(' a '); h.push('b'); h.push('a');
  assert.deepEqual(h.entries, ['a', 'b', 'a']);
});

test('push resets browsing and the cap drops the oldest', () => {
  const h = new InputHistory({ max: 3 });
  ['1', '2', '3'].forEach((x) => h.push(x));
  h.prev('');
  h.push('4');
  assert.deepEqual(h.entries, ['2', '3', '4']);
  assert.equal(h.next(), null);
  assert.equal(h.prev('d'), '4');
});

test('persists to storage and survives corrupt data', () => {
  const st = memStorage();
  const h = new InputHistory({ storage: st, key: 'k' });
  h.push('hello');
  assert.deepEqual(JSON.parse(st.d.k), ['hello']);
  assert.deepEqual(new InputHistory({ storage: st, key: 'k' }).entries, ['hello']);
  assert.deepEqual(new InputHistory({ storage: memStorage({ k: '{bad' }), key: 'k' }).entries, []);
  assert.deepEqual(new InputHistory({ storage: memStorage({ k: '[1,"ok",{"a":1}]' }), key: 'k' }).entries, ['ok']);
  assert.doesNotThrow(() => new InputHistory({ storage: { getItem() { throw new Error('blocked'); }, setItem() { throw new Error('blocked'); } } }).push('x'));
});
