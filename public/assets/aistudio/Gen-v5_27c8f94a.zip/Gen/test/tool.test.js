import { test } from 'node:test';
import assert from 'node:assert/strict';
import { redactSecrets, clampTimeoutSec, assertModelId, parseArgs, agentAsText, toolAsText, TOOL, TOOL_NAME, SYSTEM_PROMPT } from '../tool.js';

test('redactSecrets masks well-known token formats', () => {
  const samples = [
    'sk-ant-api03-abcdefghijklmnopqrstuvwx',
    'sk-proj-abcdefghijklmnopqrstuvwx',
    'AIzaSyA1234567890abcdefghijklmnopqrstuv',
    'ghp_abcdefghijklmnopqrstuvwxyz0123456789',
    'xoxb-1234567890-abcdefghij',
    'AKIAABCDEFGHIJKLMNOP',
    'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.abcdefghijklmnop'
  ];
  for (const s of samples) {
    const { text, count } = redactSecrets(`value ${s} end`);
    assert.equal(text, 'value [REDACTED] end', s);
    assert.equal(count, 1);
  }
});

test('redactSecrets masks key=value secrets, URL credentials, bearer tokens and private keys', () => {
  assert.equal(redactSecrets('GEMINI_API_KEY=abcd1234efgh').text, 'GEMINI_API_KEY=[REDACTED]');
  assert.equal(redactSecrets('{"password": "hunter2hunter2"}').text, '{"password": "[REDACTED]"}');
  assert.equal(redactSecrets("DB_PASSWORD: 'p@ss-word1'").text, "DB_PASSWORD: '[REDACTED]'");
  assert.equal(redactSecrets('postgres://bob:hunter2pw@db.local/app').text, 'postgres://bob:[REDACTED]@db.local/app');
  assert.equal(redactSecrets('Authorization: Bearer abcdef1234567890xyz').text, 'Authorization: Bearer [REDACTED]');
  assert.equal(redactSecrets('Authorization: Basic dXNlcjpwYXNzd29yZA==').text, 'Authorization: Basic [REDACTED]');
  const pem = '-----BEGIN RSA PRIVATE KEY-----\nMIIEabc\n-----END RSA PRIVATE KEY-----';
  assert.equal(redactSecrets(`a\n${pem}\nb`).text, 'a\n[REDACTED PRIVATE KEY]\nb');
  assert.match(redactSecrets('-----BEGIN PRIVATE KEY-----\ntruncated…').text, /^\[REDACTED PRIVATE KEY\]$/);
});

test('redactSecrets avoids obvious false positives', () => {
  for (const s of ['author: John Smith', 'max_tokens=4096', 'tokenize the input', 'risk-assessment-framework-document', 'ls -la /home/user', 'password:', 'exit code 0']) {
    assert.deepEqual(redactSecrets(s), { text: s, count: 0 }, s);
  }
});

test('redactSecrets masks literal extra secrets and is idempotent', () => {
  const key = 'my-very-private-key-123';
  const first = redactSecrets(`using ${key} and ${key}`, [key, 'short', undefined, 42]);
  assert.equal(first.text, 'using [REDACTED] and [REDACTED]');
  assert.equal(first.count, 2);
  assert.equal(redactSecrets(first.text).count, 0);
});

test('redactSecrets stays fast on hostile input', () => {
  const t = Date.now();
  redactSecrets('a.'.repeat(300_000));
  redactSecrets('x'.repeat(1_000_000));
  assert.ok(Date.now() - t < 2000);
});

test('clampTimeoutSec clamps, rounds and falls back', () => {
  assert.equal(clampTimeoutSec(30), 30);
  assert.equal(clampTimeoutSec(0), 1);
  assert.equal(clampTimeoutSec(9999), 120);
  assert.equal(clampTimeoutSec(4.6), 5);
  assert.equal(clampTimeoutSec(undefined), 10);
  assert.equal(clampTimeoutSec(null, 7), 7);
  assert.equal(clampTimeoutSec('abc', 7), 7);
  assert.equal(clampTimeoutSec('', 7), 7);
});

test('tool schema exposes optional timeout_seconds and persistent-cwd contract', () => {
  assert.equal(TOOL.name, TOOL_NAME);
  assert.ok(TOOL.schema.properties.timeout_seconds);
  assert.deepEqual(TOOL.schema.required, ['command', 'reason']);
  assert.match(SYSTEM_PROMPT, /working directory/);
});

test('assertModelId allow-lists characters', () => {
  assert.equal(assertModelId('gpt-5-codex'), 'gpt-5-codex');
  assert.equal(assertModelId('ft:gpt-4o:org::abc'), 'ft:gpt-4o:org::abc');
  for (const bad of ['', '../x', 'a b', 'x?y=1', 'a/b', undefined, 'x'.repeat(121)]) assert.throws(() => assertModelId(bad));
});

test('parseArgs and text fallbacks', () => {
  assert.deepEqual(parseArgs('{"a":1}'), { a: 1 });
  assert.deepEqual(parseArgs(''), {});
  assert.throws(() => parseArgs('{"a":'), /cut off/);
  assert.equal(agentAsText({ text: 'hi', calls: [{ args: { command: 'ls' } }] }), 'hi\n[ran] ls');
  assert.equal(agentAsText({ text: '', calls: [] }), '(no output)');
  assert.match(toolAsText({ results: [{ name: 'x', result: { ok: 1 }, id: 'secret-id' }] }), /^TOOL_RESULT:\n\[\{"name":"x","result":\{"ok":1\}\}\]$/);
});
