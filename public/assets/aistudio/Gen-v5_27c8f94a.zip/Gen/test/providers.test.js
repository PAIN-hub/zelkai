import { test, afterEach } from 'node:test';
import assert from 'node:assert/strict';
import { streamTurn, listModels, PROVIDERS } from '../providers.js';

const realFetch = globalThis.fetch;
afterEach(() => { globalThis.fetch = realFetch; });

const sse = (events, named = false) => ({
  ok: true,
  body: new ReadableStream({ start(c) { events.forEach((e) => c.enqueue(new TextEncoder().encode(`${named ? `event: ${e.type}\n` : ''}data: ${JSON.stringify(e)}\n\n`))); c.close(); } })
});
const json = (o) => ({ ok: true, json: async () => o });
const capture = (res) => { const seen = {}; globalThis.fetch = async (url, init) => { Object.assign(seen, { url, init, body: init?.body ? JSON.parse(init.body) : null }); return typeof res === 'function' ? res(url) : res; }; return seen; };
const user = [{ role: 'user', text: 'hi' }];

test('Claude: streams text + tool_use, sends browser-access header and max_tokens', async () => {
  const seen = capture(sse([
    { type: 'content_block_start', index: 0, content_block: { type: 'text', text: '' } },
    { type: 'content_block_delta', index: 0, delta: { type: 'text_delta', text: 'Checking ' } },
    { type: 'content_block_delta', index: 0, delta: { type: 'text_delta', text: 'disk' } },
    { type: 'content_block_stop', index: 0 },
    { type: 'content_block_start', index: 1, content_block: { type: 'tool_use', id: 'toolu_1', name: 'execute_shell_command', input: {} } },
    { type: 'content_block_delta', index: 1, delta: { type: 'input_json_delta', partial_json: '{"command":"df ' } },
    { type: 'content_block_delta', index: 1, delta: { type: 'input_json_delta', partial_json: '-h","reason":"disk","timeout_seconds":30}' } },
    { type: 'content_block_stop', index: 1 }
  ], true));
  const deltas = [];
  const t = await streamTurn('anthropic', { apiKey: 'k', model: 'claude-x', maxTokens: 1024, history: user, onText: (d) => deltas.push(d) });
  assert.equal(seen.url, 'https://api.anthropic.com/v1/messages');
  assert.equal(seen.init.headers['anthropic-dangerous-direct-browser-access'], 'true');
  assert.equal(seen.body.max_tokens, 1024);
  assert.equal(seen.body.tools[0].input_schema.properties.timeout_seconds.type, 'number');
  assert.deepEqual(deltas, ['Checking ', 'disk']);
  assert.deepEqual(t.calls, [{ id: 'toolu_1', name: 'execute_shell_command', args: { command: 'df -h', reason: 'disk', timeout_seconds: 30 } }]);
});

test('OpenAI: Responses API, strict off, function_call round trip', async () => {
  const seen = capture(sse([
    { type: 'response.output_text.delta', delta: 'Run ' },
    { type: 'response.output_item.done', output_index: 0, item: { type: 'message', role: 'assistant', content: [] } },
    { type: 'response.output_item.done', output_index: 1, item: { type: 'function_call', id: 'fc_1', call_id: 'call_1', name: 'execute_shell_command', arguments: '{"command":"ls","reason":"list"}' } },
    { type: 'response.completed', response: { output: [] } }
  ], true));
  const t = await streamTurn('openai', { apiKey: 'k', model: 'gpt-x', history: user, onText() {} });
  assert.equal(seen.url, 'https://api.openai.com/v1/responses');
  assert.equal(seen.init.headers.Authorization, 'Bearer k');
  assert.equal(seen.body.tools[0].strict, false);
  assert.deepEqual(t.calls, [{ id: 'call_1', name: 'execute_shell_command', args: { command: 'ls', reason: 'list' } }]);
  assert.equal(t.raw.length, 2);

  const next = capture(sse([{ type: 'response.output_item.done', output_index: 0, item: { type: 'message', content: [] } }], true));
  await streamTurn('openai', { apiKey: 'k', model: 'gpt-x', onText() {}, history: [...user, { role: 'agent', provider: 'openai', ...t }, { role: 'tool', provider: 'openai', results: [{ id: 'call_1', name: 'x', result: { exitCode: 0 } }] }] });
  assert.deepEqual(next.body.input.map((i) => i.type ?? i.role), ['user', 'message', 'function_call', 'function_call_output']);
});

test('Gemini: upper-case schema, merged text, thought signature kept', async () => {
  const seen = capture(sse([
    { candidates: [{ content: { parts: [{ text: 'o' }] } }] },
    { candidates: [{ content: { parts: [{ text: 'k' }] } }] },
    { candidates: [{ content: { parts: [{ functionCall: { name: 'execute_shell_command', args: { command: 'id', reason: 'r' } }, thoughtSignature: 'SIG' }] } }] }
  ]));
  const t = await streamTurn('gemini', { apiKey: 'k', model: 'models/gem-x', history: user, onText() {} });
  assert.match(seen.url, /models\/gem-x:streamGenerateContent\?alt=sse$/);
  const params = seen.body.tools[0].functionDeclarations[0].parameters;
  assert.equal(params.type, 'OBJECT');
  assert.equal(params.properties.timeout_seconds.type, 'NUMBER');
  assert.equal(t.text, 'ok');
  assert.equal(t.raw.parts[1].thoughtSignature, 'SIG');
});

test('history from another provider is replayed as plain text, never as foreign raw blocks', async () => {
  const gemTurn = { role: 'agent', provider: 'gemini', text: 'x', calls: [{ args: { command: 'ls' } }], raw: { role: 'model', parts: [{ functionCall: {} }] } };
  const hist = [...user, gemTurn, { role: 'tool', provider: 'gemini', results: [{ name: 'n', result: { exitCode: 0 } }] }];
  const seen = capture(sse([{ type: 'content_block_start', index: 0, content_block: { type: 'text', text: '' } }, { type: 'content_block_delta', index: 0, delta: { type: 'text_delta', text: 'ok' } }, { type: 'content_block_stop', index: 0 }], true));
  await streamTurn('anthropic', { apiKey: 'k', model: 'c', maxTokens: 9, history: hist, onText() {} });
  assert.deepEqual(seen.body.messages.map((m) => `${m.role}:${typeof m.content}`), ['user:string', 'assistant:string', 'user:string']);
});

test('cancelled tool results are flagged as errors for Claude', async () => {
  const hist = [...user, { role: 'agent', provider: 'anthropic', raw: [{ type: 'tool_use', id: 't1', name: 'n', input: {} }], text: '', calls: [] }, { role: 'tool', provider: 'anthropic', results: [{ id: 't1', name: 'n', result: { error: 'Cancelled by user.' } }] }];
  const seen = capture(sse([{ type: 'content_block_start', index: 0, content_block: { type: 'text', text: '' } }, { type: 'content_block_delta', index: 0, delta: { type: 'text_delta', text: 'ok' } }, { type: 'content_block_stop', index: 0 }], true));
  await streamTurn('anthropic', { apiKey: 'k', model: 'c', maxTokens: 9, history: hist, onText() {} });
  assert.equal(seen.body.messages[2].content[0].is_error, true);
});

test('listModels filters per provider', async () => {
  capture((url) => url.includes('anthropic') ? json({ data: [{ id: 'claude-b' }, { id: 'claude-a' }] })
    : url.includes('openai') ? json({ data: [{ id: 'gpt-5-codex' }, { id: 'text-embedding-3' }, { id: 'whisper-1' }, { id: 'o3' }, { id: 'dall-e-3' }] })
    : json({ models: [{ name: 'models/gemini-p', supportedGenerationMethods: ['generateContent'] }, { name: 'models/text-embedding-004', supportedGenerationMethods: ['embedContent'] }] }));
  assert.deepEqual(await listModels('anthropic', { apiKey: 'k' }), ['claude-a', 'claude-b']);
  assert.deepEqual(await listModels('openai', { apiKey: 'k' }), ['gpt-5-codex', 'o3']);
  assert.deepEqual(await listModels('gemini', { apiKey: 'k' }), ['gemini-p']);
  assert.deepEqual(Object.keys(PROVIDERS), ['gemini', 'anthropic', 'openai']);
});

test('invalid model IDs, unknown providers and Stop are handled', async () => {
  capture(sse([]));
  await assert.rejects(streamTurn('openai', { apiKey: 'k', model: '../../x', history: [], onText() {} }), /Invalid/);
  await assert.rejects(async () => streamTurn('nope', {}), /Unknown provider/);

  const ctl = new AbortController();
  globalThis.fetch = async (url, init) => ({ ok: true, body: new ReadableStream({ start(c) { init.signal.addEventListener('abort', () => c.error(new DOMException('Aborted', 'AbortError'))); } }) });
  const p = streamTurn('anthropic', { apiKey: 'k', model: 'c', maxTokens: 9, history: [], onText() {}, signal: ctl.signal });
  setTimeout(() => ctl.abort(), 20);
  await assert.rejects(p, { name: 'AbortError' });
});
