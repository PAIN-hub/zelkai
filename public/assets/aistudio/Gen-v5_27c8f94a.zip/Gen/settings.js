// settings.js — validated settings state + persistence.
// Preferences -> localStorage. API keys -> sessionStorage by default, localStorage only if "remember" is on.
import { PROVIDERS } from './providers.js';
import { clampTimeoutSec } from './tool.js';

const SETTINGS_KEY = 'nexus.settings.v1';
const KEYS_KEY = 'nexus.keys.v1';

const area = (kind) => { try { return window[kind]; } catch { return null; } };
const read = (kind, key) => { try { return JSON.parse(area(kind)?.getItem(key) ?? 'null'); } catch { return null; } };
const write = (kind, key, v) => { try { area(kind)?.setItem(key, JSON.stringify(v)); } catch { /* storage blocked */ } };
const drop = (kind, key) => { try { area(kind)?.removeItem(key); } catch { /* storage blocked */ } };

const ids = Object.keys(PROVIDERS);
const perProvider = (src, max) =>
  Object.fromEntries(ids.map((id) => [id, typeof src?.[id] === 'string' ? src[id].trim().slice(0, max) : '']));
const clamp = (n, lo, hi, d) => (Number.isFinite(+n) ? Math.min(hi, Math.max(lo, Math.round(+n))) : d);

export function sanitize(input) {
  const { settings, keys } = input && typeof input === 'object' ? input : {};
  return {
    settings: {
      provider: Object.hasOwn(PROVIDERS, settings?.provider) ? settings.provider : ids[0],
      models: perProvider(settings?.models, 120),
      maxTokens: clamp(settings?.maxTokens, 256, 64000, 4096),
      maxSteps: clamp(settings?.maxSteps, 1, 12, 6),
      timeoutSec: clampTimeoutSec(settings?.timeoutSec),
      remember: settings?.remember === true
    },
    keys: perProvider(keys, 400)
  };
}

let state = sanitize({
  settings: read('localStorage', SETTINGS_KEY),
  keys: read('localStorage', KEYS_KEY) ?? read('sessionStorage', KEYS_KEY)
});

export const getState = () => structuredClone(state);

function persistKeys() {
  const [keep, other] = state.settings.remember ? ['localStorage', 'sessionStorage'] : ['sessionStorage', 'localStorage'];
  write(keep, KEYS_KEY, state.keys);
  drop(other, KEYS_KEY);
}

export function commit(next) {
  state = sanitize(next);
  write('localStorage', SETTINGS_KEY, state.settings);
  persistKeys();
}

export function clearKeys() {
  state.keys = perProvider({}, 0);
  drop('localStorage', KEYS_KEY);
  drop('sessionStorage', KEYS_KEY);
}

export function getConfig() {
  const { settings, keys } = state;
  const p = settings.provider;
  return {
    provider: p,
    label: PROVIDERS[p].label,
    model: settings.models[p],
    apiKey: keys[p],
    maxTokens: settings.maxTokens,
    maxSteps: settings.maxSteps,
    timeoutSec: settings.timeoutSec
  };
}
