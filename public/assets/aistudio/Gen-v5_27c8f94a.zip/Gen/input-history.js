// input-history.js — shell-style Up/Down recall for the prompt box. Pure module (storage is injected).
export class InputHistory {
  #entries = [];
  #cursor = null; // null = not browsing
  #draft = '';
  #storage;
  #key;
  #max;

  constructor({ storage = null, key = 'nexus.inputHistory.v1', max = 100 } = {}) {
    this.#storage = storage;
    this.#key = key;
    this.#max = max;
    try {
      const saved = JSON.parse(storage?.getItem(key) ?? '[]');
      if (Array.isArray(saved)) this.#entries = saved.filter((s) => typeof s === 'string' && s.length <= 2000).slice(-max);
    } catch { /* corrupt or blocked storage: start empty */ }
  }

  get entries() { return [...this.#entries]; }

  push(text) {
    const t = String(text ?? '').trim();
    this.reset();
    if (!t || t === this.#entries.at(-1)) return;
    this.#entries.push(t.slice(0, 2000));
    if (this.#entries.length > this.#max) this.#entries.splice(0, this.#entries.length - this.#max);
    try { this.#storage?.setItem(this.#key, JSON.stringify(this.#entries)); } catch { /* storage blocked */ }
  }

  /** Older entry, or null when there is nothing to recall. `current` is saved as the draft on first press. */
  prev(current = '') {
    if (!this.#entries.length) return null;
    if (this.#cursor === null) {
      this.#draft = current;
      this.#cursor = this.#entries.length;
    }
    if (this.#cursor > 0) this.#cursor--;
    return this.#entries[this.#cursor];
  }

  /** Newer entry; past the newest it restores the draft. Null when not browsing. */
  next() {
    if (this.#cursor === null) return null;
    if (this.#cursor < this.#entries.length - 1) return this.#entries[++this.#cursor];
    this.#cursor = null;
    return this.#draft;
  }

  reset() { this.#cursor = null; this.#draft = ''; }
}
