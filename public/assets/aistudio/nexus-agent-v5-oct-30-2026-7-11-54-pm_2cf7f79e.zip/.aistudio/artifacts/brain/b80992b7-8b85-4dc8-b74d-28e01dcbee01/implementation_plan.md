# Nexus Settings Redesign — Implementation Plan

## 1. Overview & Architecture
We will replace the current single-modal `NexusSettingsDialog` with a structured, multi-section **Settings** architecture inspired by modern AI workspaces (ChatGPT / Claude mobile). Changes will persist automatically as the user interacts with controls (via Jetpack DataStore / SharedPreferences locally and Firestore sync when signed in), eliminating global "Save/Cancel" buttons on main settings pages while using confirmation dialogs strictly for destructive actions.

### Navigation & Responsive Layout
- **Entry Points**: Tapping **Settings** in the navigation drawer, tapping the user profile row, or tapping "Add API key" prompts opens the full-screen **Settings** experience.
- **Phone / Compact Width (`< 840.dp`)**:
  - Opens to a clean **Settings Home** list with a top app bar (`← Back`, `"Settings"` title), a prominent **Profile Summary Card** at the top, and grouped rows for **Profile**, **General**, **Model Configuration**, **Data & Privacy**, and **About** (each with an icon, title, one-line subtitle, and chevron).
  - Tapping any section navigates to its dedicated sub-page with a smooth horizontal slide/fade transition and full system back-stack support (`BackHandler`).
- **Tablet / Expanded Width (`>= 840.dp`)**:
  - Uses a two-pane **Master-Detail** layout with the 5 section rows on the left rail and the active section's sub-page rendered on the right pane.

---

## 2. Section-by-Section Design & Capabilities

### Section 1: Profile
- **Avatar & Zero-Permission Photo Picker**:
  - Displays a 72–88dp circular avatar (user photo or gradient initials fallback).
  - Tapping the avatar or **"Change photo"** opens a bottom sheet with:
    - **Choose from gallery** (`ActivityResultContracts.PickVisualMedia` — zero storage permissions required).
    - **Take photo** (`ActivityResultContracts.TakePicturePreview`).
    - **Remove photo** (restores initials avatar).
  - **Interactive 1:1 Circular Cropper Modal**: Allows pinch/zoom/pan or centered square crop, downscales to `512x512 px`, saves locally to `context.filesDir/profile/avatar.webp`, and encodes a compact WebP data URI synced to the signed-in user's Firestore settings document.
- **Identity & Account Details**:
  - **Editable Display Name**: Saves automatically on focus loss or keyboard `Done`, updating the greeting on the home empty state (`"Where should we start, <FirstName>?"`) and sidebar footer.
  - **Email / Account Type**: Read-only email with a **"Signed in with Google"** badge, or **"Guest mode"** card with a prominent **"Sign in with Google"** upgrade button.
  - **Account Actions**:
    - **Sign out** (with confirmation dialog).
    - **Delete account & cloud data** (two-step confirmation dialog requiring the user to type `DELETE` before wiping Firestore user documents, sessions, and auth state).

### Section 2: General
- **Appearance**:
  - **Theme**: Segmented control (`Light` / `Dark` / `System`) wired directly to `NexusThemeMode` with instant live preview.
  - **Font Size**: Segmented control (`Small` / `Default` / `Large`) applying a typography scale factor (`0.90f` / `1.0f` / `1.12f`) across chat messages and terminal output.
- **Response Style**:
  - Preset selector cards (`Concise`, `Balanced` [default], `Detailed`, `Technical`) that dynamically append response-style directives to the system prompt.
- **Personalization ("About you")**:
  - **"What should Nexus know about you?"** (multiline text field, up to 1,500 chars, live character counter, auto-saved).
  - **"How should Nexus respond?"** (multiline text field, up to 1,500 chars, live character counter, auto-saved).
  - **"Enable for new chats"** toggle switch controlling whether personalization instructions are injected into the system prompt.
- **Skills (Reusable Instruction Packs)**:
  - **Built-in Starter Skills** (read-only content, toggleable on/off):
    1. *Shell Safety Reviewer*
    2. *Concise Code Generator*
    3. *Step-by-Step Debugger*
    4. *Linux Admin Helper*
  - **Custom User Skills**: Users can create, edit, and delete custom skills (`Name` ≤ 50 chars, `Description` ≤ 120 chars, `Instructions` ≤ 4,000 chars, `Enabled` toggle), import/export `.md` or `.json` skill files, and configure the **Skills Token Budget** (default `2,000` tokens with a configurable slider from `500` to `6,000` tokens).
  - Displays a live token usage indicator (`~chars / 4` tokens) and a warning banner if enabled skills exceed the configured token budget.

### Section 3: Model Configuration
- **Default Active Model**:
  - Clean two-step selector (**Provider** → **Model**) bound to the single source of truth (`selectedProvider` + `selectedModelId`) synced with the chat composer model chip.
- **Cloud Providers (Expandable Cards for Google Gemini, Anthropic Claude, OpenAI)**:
  - Masked API key input with show/hide eye toggle, clipboard paste button, and Clear key action.
  - **"Test key"** button with live status badge (`Not set`, `Testing…`, `Valid (N models)`, `Invalid key`, `Quota exceeded`, `Network error`).
  - **"Refresh models"** action and count of available models (plus the `"Show all OpenAI models"` filter switch inside the OpenAI card).
- **On-Device Local Models (Summary Card)**:
  - Displays active runtime status (`LlamaCppEngine` / `StubEngine`), currently loaded model in RAM (with measured `tok/s` and **Unload** button), count of installed GGUF models, and a prominent **"Open Local LLM Hub"** button to launch the full `LocalLlmHubDialog`.
  - Expandable **"Advanced: Hugging Face Access Token"** field for gated model downloads.
- **Inference Defaults (Collapsible Advanced Accordion)**:
  - **Inference Preset**: `Speed` / `Balanced` / `Quality`.
  - **Max Output Tokens**: Slider + numeric input (`256`–`8192`, default `4096`).
  - **Max Agent Steps per Turn**: Slider (`1`–`12`, default `6`).
  - **Command Execution Timeout**: Slider (`1`–`120s`, default `10s`).
  - **Optional Remote Shell Bridge URL**: Text field.

### Section 4: Data & Privacy
- **Chat History & Sync**:
  - Cloud sync status indicator (`Active` when signed in, `Disabled` in Guest Mode).
  - **Export all chats**: Exports sessions as JSON or Markdown via Android Share sheet.
  - **Clear all chat history**: Confirmation dialog that deletes all sessions and transcript entries.
- **On-Device Storage**:
  - Breakdown of storage used by downloaded GGUF models, cached data, and preferences, with a **"Manage downloaded models"** shortcut to the Local LLM Hub.
  - **Agent Working Directory**: Shows current path and opens the `DirectoryChooserDialog` (replacing the verbose `MANAGE_EXTERNAL_STORAGE` banner with a clean single-row status & action).
- **Security**:
  - **Secret Redaction Engine**: Status row (`Always active`) with a **"View redaction rules"** info sheet explaining masked token patterns.
  - **Clear all saved API keys**: Confirmation dialog that wipes all keys from Android Keystore (`UserApiKeyStore`).

### Section 5: About
- App icon, **Nexus** name, version name/code (`BuildConfig.VERSION_NAME`), and build type.
- Runtime & device summary (Device model, SoC/ABI, total RAM, active inference engine).
- Open-source licenses & Privacy/Security summary modal sheets.

---

## 3. Data Layer & Firestore Updates
- **`NexusSettingsStore` (Local Preferences + Sync)**:
  - Stores appearance (`themeMode`, `fontScale`), response style, personalization fields (`aboutUser`, `responsePreference`, `enableForNewChats`), skills list & token budget (`skillsJson`, `skillsTokenBudget`), display name override, and local avatar path/base64 URI.
- **`NexusModels.kt` & `NexusRepository.kt` & `firestore.rules`**:
  - Extend `NexusUserSettings` with optional fields (`displayName`, `avatarDataUri`, `fontScale`, `responseStyle`, `aboutUser`, `responseInstructions`, `personalizationEnabled`, `skillsJson`, `skillsTokenBudget`) while keeping backward compatibility and updating `firestore.rules` + `firebase-blueprint.json` so signed-in users can sync these fields seamlessly.
- **System Prompt Assembly (`NexusViewModel` / `NexusToolAndRedactor`)**:
  - Dynamically combines:
    1. Base system prompt + selected **Response Style** instruction
    2. **Personalization** block (when `enableForNewChats` is ON)
    3. Enabled **Skills** instructions (up to `skillsTokenBudget`, flagging any budget overflow)
