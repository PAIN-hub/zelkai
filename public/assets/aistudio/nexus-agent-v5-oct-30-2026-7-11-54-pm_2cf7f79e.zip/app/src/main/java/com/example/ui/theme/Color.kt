package com.example.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

// Editorial Light Palette — Warm off-white (#F7F6F3), crisp hairline borders, high-contrast ink
val NexusBgLight = Color(0xFFF7F6F3)
val NexusPanelLight = Color(0xFFFFFFFF)
val NexusSurfaceLight = Color(0xFFF0EFEA)
val NexusUserBubbleLight = Color(0xFFE6E4DD)
val NexusOnUserBubbleLight = Color(0xFF111318) // Contrast vs #E6E4DD is ~13.9:1 (WCAG AAA)
val NexusAiTextLight = Color(0xFF141519)       // Contrast vs #F7F6F3 is ~15.8:1 (WCAG AAA)
val NexusBorderLight = Color(0xFFE4E2DA)
val NexusBorderStrongLight = Color(0xFFD2CFC4)
val NexusTextLight = Color(0xFF141519)
val NexusMutedLight = Color(0xFF5A5D68)

// Editorial Dark Palette — Near-black (#0B0D11), subtle slate surfaces, high-contrast text
val NexusBgDark = Color(0xFF0B0D11)
val NexusPanelDark = Color(0xFF13161D)
val NexusSurfaceDark = Color(0xFF1A1E27)
val NexusUserBubbleDark = Color(0xFF232836)
val NexusOnUserBubbleDark = Color(0xFFF8FAFC)  // Contrast vs #232836 is ~13.2:1 (WCAG AAA)
val NexusAiTextDark = Color(0xFFF1F5F9)        // Contrast vs #0B0D11 is ~16.8:1 (WCAG AAA)
val NexusBorderDark = Color(0xFF232834)
val NexusBorderStrongDark = Color(0xFF313847)
val NexusTextDark = Color(0xFFF1F5F9)
val NexusMutedDark = Color(0xFF94A3B8)

// Backward-compatible aliases
val NexusBg = NexusBgLight
val NexusPanel = NexusPanelLight
val NexusSurface = NexusSurfaceLight
val NexusBorder = NexusBorderLight
val NexusBorderStrong = NexusBorderStrongLight
val NexusText = NexusTextLight
val NexusMuted = NexusMutedLight

// Nexus Indigo → Violet Brand Accent
val NexusAccent = Color(0xFF4F46E5)
val NexusAccent2 = Color(0xFF7C3AED)
val NexusAccentSoftLight = Color(0xFFEEF2FF)
val NexusAccentSoftDark = Color(0xFF1E1B4B)
val NexusAccentSoft = NexusAccentSoftLight

// Semantic Status Colors
val NexusOk = Color(0xFF0D9488)
val NexusOkSoft = Color(0xFFCCFBF1)
val NexusWarn = Color(0xFFD97706)
val NexusWarnSoft = Color(0xFFFEF3C7)
val NexusWarnText = Color(0xFF92400E)
val NexusDanger = Color(0xFFDC2626)
val NexusDangerSoft = Color(0xFFFEE2E2)
val NexusDangerBorder = Color(0xFFFCA5A5)

// Code Block & Terminal Colors
val NexusCodeBg = Color(0xFF0E1117)
val NexusCodeHeaderBg = Color(0xFF161A23)
val NexusCodeText = Color(0xFFE6EDF3)
val NexusCodeLangText = Color(0xFF9CA3AF)

/**
 * Explicit paired color tokens for user chat bubbles, AI messages, and surfaces
 * in both Light and Dark themes. Never rely on defaults or LocalContentColor.
 */
@Immutable
data class NexusSemanticColors(
    val isDark: Boolean,
    val userBubble: Color,
    val onUserBubble: Color,
    val aiText: Color,
    val aiSecondaryText: Color,
    val surface: Color,
    val onSurface: Color,
    val surfaceVariant: Color,
    val onSurfaceVariant: Color,
    val background: Color,
    val onBackground: Color,
    val outline: Color
)

val LightNexusSemanticColors = NexusSemanticColors(
    isDark = false,
    userBubble = NexusUserBubbleLight,
    onUserBubble = NexusOnUserBubbleLight,
    aiText = NexusAiTextLight,
    aiSecondaryText = NexusMutedLight,
    surface = NexusPanelLight,
    onSurface = NexusTextLight,
    surfaceVariant = NexusSurfaceLight,
    onSurfaceVariant = NexusMutedLight,
    background = NexusBgLight,
    onBackground = NexusTextLight,
    outline = NexusBorderLight
)

val DarkNexusSemanticColors = NexusSemanticColors(
    isDark = true,
    userBubble = NexusUserBubbleDark,
    onUserBubble = NexusOnUserBubbleDark,
    aiText = NexusAiTextDark,
    aiSecondaryText = NexusMutedDark,
    surface = NexusPanelDark,
    onSurface = NexusTextDark,
    surfaceVariant = NexusSurfaceDark,
    onSurfaceVariant = NexusMutedDark,
    background = NexusBgDark,
    onBackground = NexusTextDark,
    outline = NexusBorderDark
)

val LocalNexusColors = staticCompositionLocalOf { LightNexusSemanticColors }

/**
 * Computes WCAG 2.1 contrast ratio between [foreground] and [background].
 * WCAG AA requires >= 4.5:1 for normal text.
 */
fun wcagContrastRatio(foreground: Color, background: Color): Double {
    fun channelLuminance(c: Float): Double {
        val v = c.toDouble().coerceIn(0.0, 1.0)
        return if (v <= 0.03928) v / 12.92 else ((v + 0.055) / 1.055).pow(2.4)
    }
    fun relativeLuminance(color: Color): Double {
        return 0.2126 * channelLuminance(color.red) +
            0.7152 * channelLuminance(color.green) +
            0.0722 * channelLuminance(color.blue)
    }
    val l1 = relativeLuminance(foreground)
    val l2 = relativeLuminance(background)
    val lighter = max(l1, l2)
    val darker = min(l1, l2)
    return (lighter + 0.05) / (darker + 0.05)
}
