package com.example.domain

import android.content.Context
import android.os.PowerManager
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

private val Context.termuxSetupWizardDataStore by preferencesDataStore(name = "nexus_termux_wizard_prefs_v5")

enum class DiagnosticStatus {
    OK,
    MISSING,
    ERROR,
    UNKNOWN
}

enum class DiagnosticFixAction {
    NONE,
    OPEN_GITHUB_RELEASES,
    OPEN_FDROID,
    REQUEST_RUN_COMMAND_PERMISSION,
    OPEN_APP_PERMISSION_SETTINGS,
    COPY_ALLOW_EXTERNAL_APPS_CMD,
    OPEN_TERMUX,
    OPEN_BATTERY_OPTIMIZATION_SETTINGS,
    COPY_TERMUX_SETUP_STORAGE_CMD,
    PROPOSE_INSTALL_TOOLCHAIN
}

data class DiagnosticCheckItem(
    val id: String,
    val title: String,
    val status: DiagnosticStatus,
    val plainMessage: String,
    val probableCause: String = "",
    val fixAction: DiagnosticFixAction = DiagnosticFixAction.NONE,
    val fixActionLabel: String = "",
    val secondaryAction: DiagnosticFixAction = DiagnosticFixAction.NONE,
    val secondaryActionLabel: String = "",
    val commandSnippet: String? = null
)

data class SelfTestStepResult(
    val stepId: String,
    val title: String,
    val passed: Boolean,
    val durationMs: Long,
    val detail: String
)

data class SelfTestReport(
    val passed: Boolean,
    val totalDurationMs: Long,
    val steps: List<SelfTestStepResult>,
    val timestampMs: Long = System.currentTimeMillis()
)

data class TermuxDiagnosticsReport(
    val checks: List<DiagnosticCheckItem>,
    val detectedTools: List<DetectedToolInfo>,
    val isFullyReady: Boolean,
    val needsSetupBadge: Boolean,
    val timestampMs: Long = System.currentTimeMillis()
)

enum class WorkspaceProjectType(val id: String, val label: String, val badge: String) {
    NODE_JS("nodejs", "Node.js Project (package.json)", "Node.js"),
    PYTHON("python", "Python Project (requirements.txt / pyproject.toml)", "Python"),
    STATIC_WEB("static_web", "Static HTML Site (index.html)", "HTML/Web"),
    GIT_REPO("git_repo", "Git Repository (.git)", "Git"),
    GENERAL("general", "General Workspace", "Shell")
}

data class ProjectRecipeStep(
    val id: String,
    val title: String,
    val description: String,
    val command: String,
    val verifyCommand: String,
    val isVerified: Boolean = false
)

data class ProjectSetupGuideReport(
    val detectedTypes: List<WorkspaceProjectType>,
    val prerequisites: List<Pair<String, Boolean>>,
    val recipes: List<ProjectRecipeStep>
)

data class TermuxWizardState(
    val currentStepIndex: Int = 0,
    val completed: Boolean = false,
    val skipped: Boolean = false,
    val keepTermuxAwakeWhileJobsRun: Boolean = true,
    val pendingCorrelationIds: Set<String> = emptySet()
)

/**
 * Persists Termux Setup Wizard progress, "Keep Termux awake while jobs run" preference,
 * and pending correlation IDs in Jetpack DataStore so process death never leaves stuck commands.
 */
class TermuxWizardStore(private val context: Context) {
    private val keyStepIndex = intPreferencesKey("wizard_step_index")
    private val keyCompleted = booleanPreferencesKey("wizard_completed")
    private val keySkipped = booleanPreferencesKey("wizard_skipped")
    private val keyKeepAwake = booleanPreferencesKey("keep_termux_awake_while_jobs_run")
    private val keyPendingCorrelations = stringPreferencesKey("pending_correlation_ids")

    val stateFlow: Flow<TermuxWizardState> = context.termuxSetupWizardDataStore.data.map { prefs ->
        val rawIds = prefs[keyPendingCorrelations].orEmpty()
        val parsedIds = rawIds.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
        TermuxWizardState(
            currentStepIndex = prefs[keyStepIndex] ?: 0,
            completed = prefs[keyCompleted] ?: false,
            skipped = prefs[keySkipped] ?: false,
            keepTermuxAwakeWhileJobsRun = prefs[keyKeepAwake] ?: true,
            pendingCorrelationIds = parsedIds
        )
    }

    suspend fun getState(): TermuxWizardState = stateFlow.first()

    suspend fun updateStep(stepIndex: Int) {
        context.termuxSetupWizardDataStore.edit { prefs ->
            prefs[keyStepIndex] = stepIndex.coerceAtLeast(0)
        }
    }

    suspend fun markCompleted(completed: Boolean = true) {
        context.termuxSetupWizardDataStore.edit { prefs ->
            prefs[keyCompleted] = completed
            if (completed) prefs[keySkipped] = false
        }
    }

    suspend fun markSkipped(skipped: Boolean = true) {
        context.termuxSetupWizardDataStore.edit { prefs ->
            prefs[keySkipped] = skipped
        }
    }

    suspend fun setKeepTermuxAwake(enabled: Boolean) {
        context.termuxSetupWizardDataStore.edit { prefs ->
            prefs[keyKeepAwake] = enabled
        }
    }

    suspend fun registerPendingCorrelationId(correlationId: String) {
        context.termuxSetupWizardDataStore.edit { prefs ->
            val current = prefs[keyPendingCorrelations].orEmpty()
                .split(",")
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .toMutableSet()
            current.add(correlationId)
            prefs[keyPendingCorrelations] = current.joinToString(",")
        }
    }

    suspend fun removePendingCorrelationId(correlationId: String) {
        context.termuxSetupWizardDataStore.edit { prefs ->
            val current = prefs[keyPendingCorrelations].orEmpty()
                .split(",")
                .map { it.trim() }
                .filter { it.isNotEmpty() && it != correlationId }
            prefs[keyPendingCorrelations] = current.joinToString(",")
        }
    }

    /**
     * Reconciles any correlation IDs left over from a killed app process and clears them.
     */
    suspend fun consumeStaleCorrelationIdsOnRestart(): Set<String> {
        var stale = emptySet<String>()
        context.termuxSetupWizardDataStore.edit { prefs ->
            stale = prefs[keyPendingCorrelations].orEmpty()
                .split(",")
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .toSet()
            prefs[keyPendingCorrelations] = ""
        }
        return stale
    }
}

/**
 * Pluggable interface for Termux diagnostics & command probes so [FakeTermux] can simulate
 * every state and error deterministically in unit tests.
 */
interface TermuxEnvironmentProbe {
    fun isTermuxPackageInstalled(): Boolean
    fun isRunCommandPermissionGranted(): Boolean
    fun isTermuxBatteryOptimizationExempt(): Boolean
    fun isSharedStorageWritable(workspacePath: String): Boolean
    suspend fun pingTermuxReachability(timeoutSec: Long = 10L): Pair<Boolean, String>
    suspend fun probeInstalledTools(): List<DetectedToolInfo>
    suspend fun runRawCommand(cmd: String, cwd: String, timeoutSec: Long = 30L): TermuxPluginResult
}

/**
 * Sequential, non-blocking Termux Diagnostics Engine with 60-second caching,
 * End-to-End Self-Test runner, per-package fallback installer, and Project Setup Guide detector.
 */
class TermuxDiagnostics(
    private val probe: TermuxEnvironmentProbe,
    private val cacheTtlMs: Long = 60_000L,
    private val clock: () -> Long = { System.currentTimeMillis() }
) {
    private val mutex = Mutex()
    private var cachedReport: TermuxDiagnosticsReport? = null

    constructor(context: Context, termuxBackend: TermuxBackend) : this(
        probe = AndroidTermuxEnvironmentProbe(context.applicationContext, termuxBackend)
    )

    fun invalidateCache() {
        cachedReport = null
    }

    suspend fun runDiagnostics(
        workspaceCwd: String,
        workspaceMode: WorkspaceMode,
        forceRefresh: Boolean = false
    ): TermuxDiagnosticsReport = withContext(Dispatchers.IO) {
        mutex.withLock {
            val now = clock()
            val existing = cachedReport
            if (!forceRefresh && existing != null && (now - existing.timestampMs) < cacheTtlMs) {
                return@withLock existing
            }

            val checks = mutableListOf<DiagnosticCheckItem>()

            // 1. Termux Installed check
            val installed = runCatching { probe.isTermuxPackageInstalled() }.getOrDefault(false)
            checks.add(
                if (installed) {
                    DiagnosticCheckItem(
                        id = "termux_installed",
                        title = "Termux Installed",
                        status = DiagnosticStatus.OK,
                        plainMessage = "Termux package (com.termux) is installed."
                    )
                } else {
                    DiagnosticCheckItem(
                        id = "termux_installed",
                        title = "Termux Installed",
                        status = DiagnosticStatus.MISSING,
                        plainMessage = "Termux is not installed on this device.",
                        probableCause = "Install Termux and any add-ons from the SAME source (GitHub Releases or F-Droid) to avoid signature conflicts. Do NOT use the outdated Google Play Store build.",
                        fixAction = DiagnosticFixAction.OPEN_GITHUB_RELEASES,
                        fixActionLabel = "GitHub Releases",
                        secondaryAction = DiagnosticFixAction.OPEN_FDROID,
                        secondaryActionLabel = "F-Droid"
                    )
                }
            )

            // 2. RUN_COMMAND Permission check
            val permGranted = if (installed) {
                runCatching { probe.isRunCommandPermissionGranted() }.getOrDefault(false)
            } else {
                false
            }
            checks.add(
                when {
                    !installed -> DiagnosticCheckItem(
                        id = "run_command_permission",
                        title = "RUN_COMMAND Permission",
                        status = DiagnosticStatus.UNKNOWN,
                        plainMessage = "Waiting for Termux installation before requesting permission."
                    )
                    permGranted -> DiagnosticCheckItem(
                        id = "run_command_permission",
                        title = "RUN_COMMAND Permission",
                        status = DiagnosticStatus.OK,
                        plainMessage = "com.termux.permission.RUN_COMMAND is granted."
                    )
                    else -> DiagnosticCheckItem(
                        id = "run_command_permission",
                        title = "RUN_COMMAND Permission",
                        status = DiagnosticStatus.MISSING,
                        plainMessage = "Nexus needs permission to send commands to Termux.",
                        probableCause = "Android requires explicit runtime approval for com.termux.permission.RUN_COMMAND. If permanently denied, grant it in App Settings > Permissions.",
                        fixAction = DiagnosticFixAction.REQUEST_RUN_COMMAND_PERMISSION,
                        fixActionLabel = "Grant permission",
                        secondaryAction = DiagnosticFixAction.OPEN_APP_PERMISSION_SETTINGS,
                        secondaryActionLabel = "App settings"
                    )
                }
            )

            // 3 & 4. allow-external-apps & Termux Reachability (`echo nexus_ok` with 10s timeout)
            var reachableOk = false
            var externalAppsOk = false
            var pingDetail = ""

            if (installed && permGranted) {
                val (ok, detail) = runCatching { probe.pingTermuxReachability(10L) }
                    .getOrDefault(false to "Termux ping failed")
                pingDetail = detail
                if (ok) {
                    reachableOk = true
                    externalAppsOk = true
                } else {
                    val lowerDetail = detail.lowercase()
                    if (lowerDetail.contains("allow-external-apps") ||
                        lowerDetail.contains("permission") ||
                        lowerDetail.contains("properties") ||
                        lowerDetail.contains("securityexception")
                    ) {
                        externalAppsOk = false
                        reachableOk = false
                    } else {
                        // Could be external-apps disabled OR Termux service not started
                        externalAppsOk = false
                        reachableOk = false
                    }
                }
            }

            checks.add(
                when {
                    !installed || !permGranted -> DiagnosticCheckItem(
                        id = "allow_external_apps",
                        title = "allow-external-apps Enabled",
                        status = DiagnosticStatus.UNKNOWN,
                        plainMessage = "Inferred via test command once Termux is installed and permission is granted.",
                        commandSnippet = TermuxBackend.ONE_TIME_SETUP_COMMAND,
                        fixAction = DiagnosticFixAction.COPY_ALLOW_EXTERNAL_APPS_CMD,
                        fixActionLabel = "Copy command"
                    )
                    externalAppsOk -> DiagnosticCheckItem(
                        id = "allow_external_apps",
                        title = "allow-external-apps Enabled",
                        status = DiagnosticStatus.OK,
                        plainMessage = "Termux accepted external command execution (`echo nexus_ok`)."
                    )
                    else -> DiagnosticCheckItem(
                        id = "allow_external_apps",
                        title = "allow-external-apps Enabled",
                        status = DiagnosticStatus.MISSING,
                        plainMessage = "Termux did not accept external commands ($pingDetail).",
                        probableCause = "Set allow-external-apps = true in ~/.termux/termux.properties, then run termux-reload-settings or fully close and reopen Termux.",
                        fixAction = DiagnosticFixAction.COPY_ALLOW_EXTERNAL_APPS_CMD,
                        fixActionLabel = "Copy command",
                        secondaryAction = DiagnosticFixAction.OPEN_TERMUX,
                        secondaryActionLabel = "Open Termux",
                        commandSnippet = TermuxBackend.ONE_TIME_SETUP_COMMAND
                    )
                }
            )

            checks.add(
                when {
                    !installed || !permGranted -> DiagnosticCheckItem(
                        id = "termux_reachable",
                        title = "Termux Service Reachable",
                        status = DiagnosticStatus.UNKNOWN,
                        plainMessage = "Waiting for Termux installation and RUN_COMMAND permission."
                    )
                    reachableOk -> DiagnosticCheckItem(
                        id = "termux_reachable",
                        title = "Termux Service Reachable",
                        status = DiagnosticStatus.OK,
                        plainMessage = "Termux responded to `echo nexus_ok` ($pingDetail)."
                    )
                    else -> DiagnosticCheckItem(
                        id = "termux_reachable",
                        title = "Termux Service Reachable",
                        status = DiagnosticStatus.ERROR,
                        plainMessage = "No reply to `echo nexus_ok` within 10s.",
                        probableCause = "Termux was killed by Android or has not been started yet, or allow-external-apps is off.",
                        fixAction = DiagnosticFixAction.OPEN_TERMUX,
                        fixActionLabel = "Open Termux"
                    )
                }
            )

            // 5. Battery optimization check
            val batteryExempt = if (installed) {
                runCatching { probe.isTermuxBatteryOptimizationExempt() }.getOrDefault(false)
            } else {
                false
            }
            checks.add(
                when {
                    !installed -> DiagnosticCheckItem(
                        id = "battery_optimization",
                        title = "Battery Optimization Exemption",
                        status = DiagnosticStatus.UNKNOWN,
                        plainMessage = "Install Termux first to check battery optimization status."
                    )
                    batteryExempt -> DiagnosticCheckItem(
                        id = "battery_optimization",
                        title = "Battery Optimization Exemption",
                        status = DiagnosticStatus.OK,
                        plainMessage = "Termux is exempt from Android battery restrictions."
                    )
                    else -> DiagnosticCheckItem(
                        id = "battery_optimization",
                        title = "Battery Optimization Exemption",
                        status = DiagnosticStatus.MISSING,
                        plainMessage = "Termux is subject to background battery restrictions.",
                        probableCause = "Android phantom/background killers may terminate long-running npm/python builds or servers unless Termux is set to Unrestricted battery usage.",
                        fixAction = DiagnosticFixAction.OPEN_BATTERY_OPTIMIZATION_SETTINGS,
                        fixActionLabel = "Battery settings"
                    )
                }
            )

            // 6. Storage check (only when workspace is in shared storage)
            if (workspaceMode == WorkspaceMode.SHARED_STORAGE) {
                val writable = runCatching { probe.isSharedStorageWritable(workspaceCwd) }.getOrDefault(false)
                checks.add(
                    if (writable) {
                        DiagnosticCheckItem(
                            id = "shared_storage",
                            title = "Workspace Storage Writable",
                            status = DiagnosticStatus.OK,
                            plainMessage = "Shared workspace is writable (${NexusToolAndRedactor.shortenPathMiddle(workspaceCwd, 34)})."
                        )
                    } else {
                        DiagnosticCheckItem(
                            id = "shared_storage",
                            title = "Workspace Storage Writable",
                            status = DiagnosticStatus.MISSING,
                            plainMessage = "Shared storage workspace is not writable.",
                            probableCause = "Run `termux-setup-storage` inside Termux so Android shows the interactive storage permission dialog.",
                            fixAction = DiagnosticFixAction.COPY_TERMUX_SETUP_STORAGE_CMD,
                            fixActionLabel = "Copy command",
                            secondaryAction = DiagnosticFixAction.OPEN_TERMUX,
                            secondaryActionLabel = "Open Termux",
                            commandSnippet = "termux-setup-storage"
                        )
                    }
                )
            } else {
                checks.add(
                    DiagnosticCheckItem(
                        id = "shared_storage",
                        title = "Termux Home Workspace",
                        status = DiagnosticStatus.OK,
                        plainMessage = "Using native Termux home (${TermuxBackend.TERMUX_HOME_DIR}) with full symlink & chmod support."
                    )
                )
            }

            // 7. Tools check (node, npm, git, python, pip via `command -v` and `--version`)
            val tools = if (reachableOk) {
                runCatching { probe.probeInstalledTools() }.getOrElse {
                    defaultMissingTools()
                }
            } else {
                defaultMissingTools()
            }

            val missingTools = tools.filter { !it.isAvailable }
            val installedTools = tools.filter { it.isAvailable }
            checks.add(
                when {
                    !reachableOk -> DiagnosticCheckItem(
                        id = "developer_tools",
                        title = "Developer Toolchain (node, npm, git, python, pip)",
                        status = DiagnosticStatus.UNKNOWN,
                        plainMessage = "Connect Termux first to probe installed developer tools."
                    )
                    missingTools.isEmpty() -> DiagnosticCheckItem(
                        id = "developer_tools",
                        title = "Developer Toolchain (node, npm, git, python, pip)",
                        status = DiagnosticStatus.OK,
                        plainMessage = "All 5 tools ready: " + installedTools.joinToString(", ") {
                            "${it.name} (${it.version ?: "ok"})"
                        }
                    )
                    else -> DiagnosticCheckItem(
                        id = "developer_tools",
                        title = "Developer Toolchain (${installedTools.size}/${tools.size} ready)",
                        status = DiagnosticStatus.MISSING,
                        plainMessage = "Missing: ${missingTools.joinToString(", ") { it.name }}.",
                        probableCause = "Tap 'Install' to propose `${TermuxBackend.INSTALL_TOOLCHAIN_COMMAND}` through the command approval gate.",
                        fixAction = DiagnosticFixAction.PROPOSE_INSTALL_TOOLCHAIN,
                        fixActionLabel = "Install",
                        commandSnippet = TermuxBackend.INSTALL_TOOLCHAIN_COMMAND
                    )
                }
            )

            val fullyReady = installed && permGranted && externalAppsOk && reachableOk && missingTools.isEmpty()
            val report = TermuxDiagnosticsReport(
                checks = checks,
                detectedTools = tools,
                isFullyReady = fullyReady,
                needsSetupBadge = !fullyReady,
                timestampMs = now
            )
            cachedReport = report
            report
        }
    }

    /**
     * End-to-end Self-Test with per-step progress and timings:
     * 1) Write a test file in the workspace
     * 2) Run `node -e`
     * 3) Run `git init` in a temporary directory
     * 4) Clean up temporary artifacts
     */
    suspend fun runEndToEndSelfTest(
        workspaceCwd: String,
        onStepProgress: (List<SelfTestStepResult>) -> Unit = {}
    ): SelfTestReport = withContext(Dispatchers.IO) {
        val overallStart = clock()
        val results = mutableListOf<SelfTestStepResult>()
        val targetCwd = workspaceCwd.ifBlank { TermuxBackend.TERMUX_HOME_DIR }
        val escapedCwd = targetCwd.replace("'", "'\\''")
        val tempDir = "$targetCwd/.nexus_selftest_${clock() % 100_000}"
        val escapedTempDir = tempDir.replace("'", "'\\''")

        suspend fun runStep(id: String, title: String, cmd: String): Boolean {
            val stepStart = clock()
            val res = runCatching { probe.runRawCommand(cmd, targetCwd, 25L) }.getOrElse { e ->
                TermuxPluginResult("", e.localizedMessage ?: "error", 1, -1, e.localizedMessage)
            }
            val elapsed = (clock() - stepStart).coerceAtLeast(1L)
            val passed = res.exitCode == 0 && res.errCode == 0
            val detail = if (passed) {
                res.stdout.trim().lines().firstOrNull()?.take(80).orEmpty().ifBlank { "OK (${elapsed}ms)" }
            } else {
                (res.stderr.ifBlank { res.errMsg.orEmpty() }).trim().lines().lastOrNull()?.take(100)
                    ?: "Failed with exit ${res.exitCode}"
            }
            results.add(
                SelfTestStepResult(
                    stepId = id,
                    title = title,
                    passed = passed,
                    durationMs = elapsed,
                    detail = detail
                )
            )
            onStepProgress(results.toList())
            return passed
        }

        // Step 1: Write file in workspace
        runStep(
            id = "write_workspace_file",
            title = "1. Write file in workspace",
            cmd = "mkdir -p '$escapedTempDir' && printf 'nexus-selftest-ok\\n' > '$escapedTempDir/hello.txt' && cat '$escapedTempDir/hello.txt'"
        )

        // Step 2: Run node -e
        runStep(
            id = "node_eval",
            title = "2. Execute Node.js (`node -e`)",
            cmd = "node -e \"console.log('node-ok-' + process.version)\""
        )

        // Step 3: Run git init in temp folder
        runStep(
            id = "git_init_temp",
            title = "3. Initialize Git repo (`git init`)",
            cmd = "git init '$escapedTempDir/repo' && git -C '$escapedTempDir/repo' status --short"
        )

        // Step 4: Clean up temp folder
        runStep(
            id = "cleanup_temp",
            title = "4. Clean up temporary self-test artifacts",
            cmd = "rm -rf '$escapedTempDir' && echo 'cleaned'"
        )

        val totalMs = (clock() - overallStart).coerceAtLeast(1L)
        SelfTestReport(
            passed = results.all { it.passed },
            totalDurationMs = totalMs,
            steps = results
        )
    }

    /**
     * When batch `pkg update -y && pkg install -y nodejs git python` fails,
     * retries installing each package one-by-one and reports which package(s) succeeded or failed.
     */
    suspend fun retryToolchainPackagesIndividually(
        workspaceCwd: String,
        packages: List<String> = listOf("nodejs", "git", "python")
    ): Map<String, Pair<Boolean, String>> = withContext(Dispatchers.IO) {
        val outcomes = LinkedHashMap<String, Pair<Boolean, String>>()
        for (pkg in packages) {
            val res = runCatching {
                probe.runRawCommand("pkg install -y $pkg", workspaceCwd, 300L)
            }.getOrElse { e ->
                TermuxPluginResult("", e.localizedMessage ?: "error", 1, -1, e.localizedMessage)
            }
            val ok = res.exitCode == 0 && res.errCode == 0
            val detail = if (ok) {
                "Installed $pkg"
            } else {
                (res.stderr.ifBlank { res.stdout }).lines().lastOrNull { it.isNotBlank() }?.take(100)
                    ?: "Exit code ${res.exitCode}"
            }
            outcomes[pkg] = ok to detail
        }
        invalidateCache()
        outcomes
    }

    /**
     * Inspects the workspace directory for project markers (`package.json`, `requirements.txt`,
     * `pyproject.toml`, `index.html`, `.git`) and builds the Project Setup Guide + interactive recipes.
     */
    fun inspectWorkspaceProjectGuide(
        workspaceCwd: String,
        detectedTools: List<DetectedToolInfo>,
        verifiedRecipeIds: Set<String> = emptySet()
    ): ProjectSetupGuideReport {
        val dir = File(workspaceCwd)
        val types = mutableListOf<WorkspaceProjectType>()
        if (File(dir, "package.json").exists()) types.add(WorkspaceProjectType.NODE_JS)
        if (File(dir, "requirements.txt").exists() || File(dir, "pyproject.toml").exists()) {
            types.add(WorkspaceProjectType.PYTHON)
        }
        if (File(dir, "index.html").exists()) types.add(WorkspaceProjectType.STATIC_WEB)
        if (File(dir, ".git").exists()) types.add(WorkspaceProjectType.GIT_REPO)
        if (types.isEmpty()) types.add(WorkspaceProjectType.GENERAL)

        val toolMap = detectedTools.associateBy({ it.name.lowercase() }, { it.isAvailable })
        val prereqs = mutableListOf<Pair<String, Boolean>>()
        prereqs.add("Workspace directory exists (${NexusToolAndRedactor.shortenPathMiddle(workspaceCwd, 28)})" to dir.exists())
        if (types.contains(WorkspaceProjectType.NODE_JS)) {
            prereqs.add("Node.js & npm installed" to (toolMap["node"] == true && toolMap["npm"] == true))
            prereqs.add("node_modules installed" to File(dir, "node_modules").exists())
        }
        if (types.contains(WorkspaceProjectType.PYTHON)) {
            prereqs.add("Python & pip installed" to (toolMap["python"] == true && toolMap["pip"] == true))
            prereqs.add("Virtual environment (.venv) created" to File(dir, ".venv").exists())
        }
        if (types.contains(WorkspaceProjectType.GIT_REPO)) {
            prereqs.add("Git installed" to (toolMap["git"] == true))
        }

        val recipes = listOf(
            ProjectRecipeStep(
                id = "recipe_node_express",
                title = "Node / Express Server",
                description = "Initialize package.json, install Express, and start an HTTP server on port 3000.",
                command = "npm init -y && npm install express && node -e \"const express=require('express');const app=express();app.get('/',(req,res)=>res.send('Nexus Express Ready'));app.listen(3000,()=>console.log('Listening on http://127.0.0.1:3000'));\"",
                verifyCommand = "test -f package.json && node -v",
                isVerified = verifiedRecipeIds.contains("recipe_node_express")
            ),
            ProjectRecipeStep(
                id = "recipe_static_site",
                title = "Static Site Server (python -m http.server)",
                description = "Serve index.html and static files in the current workspace over localhost:8000.",
                command = "python3 -m http.server 8000 --bind 127.0.0.1",
                verifyCommand = "python3 --version",
                isVerified = verifiedRecipeIds.contains("recipe_static_site")
            ),
            ProjectRecipeStep(
                id = "recipe_flask_server",
                title = "Python Flask Server",
                description = "Create a virtual environment, install Flask, and start a local development server on port 5000.",
                command = "python3 -m venv .venv && . .venv/bin/activate && pip install flask && python3 -c \"from flask import Flask; app=Flask(__name__); app.route('/')(lambda: 'Nexus Flask Ready'); app.run(host='127.0.0.1', port=5000)\"",
                verifyCommand = "test -d .venv && .venv/bin/python -c 'import flask'",
                isVerified = verifiedRecipeIds.contains("recipe_flask_server")
            ),
            ProjectRecipeStep(
                id = "recipe_git_clone_install",
                title = "Git Clone & Install Dependencies",
                description = "Initialize or verify Git repository configuration and install project dependencies.",
                command = "git init && git status",
                verifyCommand = "test -d .git && git status --short",
                isVerified = verifiedRecipeIds.contains("recipe_git_clone_install")
            ),
            ProjectRecipeStep(
                id = "recipe_python_venv",
                title = "Python Virtual Environment (.venv) Setup",
                description = "Create an isolated PEP 668 compliant virtual environment in .venv and upgrade pip.",
                command = "python3 -m venv .venv && .venv/bin/pip install --upgrade pip",
                verifyCommand = "test -x .venv/bin/python && .venv/bin/python --version",
                isVerified = verifiedRecipeIds.contains("recipe_python_venv")
            )
        )

        return ProjectSetupGuideReport(
            detectedTypes = types,
            prerequisites = prereqs,
            recipes = recipes
        )
    }

    private fun defaultMissingTools(): List<DetectedToolInfo> {
        return listOf("node", "npm", "git", "python", "pip").map {
            DetectedToolInfo(name = it, binaryName = it, isAvailable = false)
        }
    }
}

/**
 * Production implementation of [TermuxEnvironmentProbe] backed by Android system services and [TermuxBackend].
 */
class AndroidTermuxEnvironmentProbe(
    private val context: Context,
    private val termuxBackend: TermuxBackend
) : TermuxEnvironmentProbe {

    override fun isTermuxPackageInstalled(): Boolean = termuxBackend.isTermuxPackageInstalled()

    override fun isRunCommandPermissionGranted(): Boolean = termuxBackend.isRunCommandPermissionGranted()

    override fun isTermuxBatteryOptimizationExempt(): Boolean {
        return runCatching {
            val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            pm?.isIgnoringBatteryOptimizations(TermuxBackend.TERMUX_PACKAGE_NAME) ?: false
        }.getOrDefault(false)
    }

    override fun isSharedStorageWritable(workspacePath: String): Boolean {
        return runCatching {
            val dir = File(workspacePath)
            if (!dir.exists()) dir.mkdirs()
            dir.exists() && dir.canRead() && dir.canWrite()
        }.getOrDefault(false)
    }

    override suspend fun pingTermuxReachability(timeoutSec: Long): Pair<Boolean, String> {
        return termuxBackend.testConnection(timeoutSec = timeoutSec)
    }

    override suspend fun probeInstalledTools(): List<DetectedToolInfo> {
        return termuxBackend.probeTools()
    }

    override suspend fun runRawCommand(cmd: String, cwd: String, timeoutSec: Long): TermuxPluginResult {
        val out = StringBuilder()
        val err = StringBuilder()
        var exit = 1
        var errMsg: String? = null
        termuxBackend.exec(cmd = cmd, cwd = cwd, timeoutSec = timeoutSec).collect { ev ->
            when (ev) {
                is ExecEvent.StdoutChunk -> out.append(ev.text)
                is ExecEvent.StderrChunk -> err.append(ev.text)
                is ExecEvent.Completed -> {
                    exit = ev.exitCode
                    errMsg = ev.errorMessage
                }
            }
        }
        return TermuxPluginResult(
            stdout = out.toString(),
            stderr = err.toString(),
            exitCode = exit,
            errCode = if (errMsg != null && exit != 0) 1 else 0,
            errMsg = errMsg
        )
    }
}
