package com.example

import android.content.Context
import android.os.Looper
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.TranscriptEntry
import com.example.domain.CommandRiskLevel
import com.example.domain.CwdValidationResult
import com.example.domain.DeviceProfiler
import com.example.domain.DeviceTier
import com.example.domain.EngineProvider
import com.example.domain.InferencePreset
import com.example.domain.LocalInferenceEngine
import com.example.domain.LocalLlmManager
import com.example.domain.LocalModelNotLoadedException
import com.example.domain.LocalShellBridge
import com.example.domain.MissingApiKeyException
import com.example.domain.ModelRegistry
import com.example.domain.MultiPlatformAiEngine
import com.example.domain.ProviderModelRepository
import com.example.domain.ProviderTransport
import com.example.domain.RecommendationBucket
import com.example.domain.RecommendationEngine
import com.example.domain.StubEngine
import com.example.domain.ToolCall
import com.example.domain.ToolCallParseResult
import com.example.domain.ToolCallParser
import com.example.domain.UserApiKeyStore
import com.example.ui.nexus.NexusViewModel
import com.example.ui.nexus.UiState
import com.example.ui.theme.DarkNexusSemanticColors
import com.example.ui.theme.LightNexusSemanticColors
import com.example.ui.theme.wcagContrastRatio
import com.example.util.NexusNotificationHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.runBlocking
import okhttp3.OkHttpClient
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import okio.Buffer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import java.io.File
import java.security.MessageDigest
import java.time.Duration

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleUnitTest {

    private fun pumpMainLooper(ms: Long = 50L) {
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(ms))
    }

    private suspend fun awaitViewModelIdle(viewModel: NexusViewModel, timeoutMs: Long = 8000L) {
        val start = System.currentTimeMillis()
        pumpMainLooper(50L)
        delay(20L)
        pumpMainLooper(50L)
        while (viewModel.isRunning.value && System.currentTimeMillis() - start < timeoutMs) {
            delay(20L)
            pumpMainLooper(60L)
        }
        pumpMainLooper(50L)
    }

    private suspend fun currentEntries(viewModel: NexusViewModel): List<TranscriptEntry> {
        pumpMainLooper(50L)
        val state = viewModel.entriesState.first { it is UiState.Success }
        pumpMainLooper(50L)
        return (state as UiState.Success).data
    }

    @Test
    fun toolCallParser_parsesFenceVariants_jsonFallback_andRejectsMalformedOrMultiLine() {
        // 1) Canonical ```sh-exec fence
        val shExecRes = ToolCallParser.parse(
            """
            Creating the web folder now:
            ```sh-exec
            mkdir -p web
            ```
            """.trimIndent()
        )
        assertTrue(shExecRes is ToolCallParseResult.Success)
        val shExecCall = (shExecRes as ToolCallParseResult.Success).toolCall
        assertEquals("mkdir -p web", shExecCall.command)
        assertEquals("sh-exec", shExecCall.source)
        assertEquals(CommandRiskLevel.LOW, shExecCall.riskLevel)

        // 2) Tolerated fence variants: ```bash, ```sh, ```shell
        for (fence in listOf("bash", "sh", "shell")) {
            val res = ToolCallParser.parse("```$fence\nls -la\n```")
            assertTrue("Fence $fence must parse as Success", res is ToolCallParseResult.Success)
            assertEquals("ls -la", (res as ToolCallParseResult.Success).toolCall.command)
        }

        // 3) JSON fallback {"tool":"shell","command":"..."}
        val jsonFallbackRes = ToolCallParser.parse(
            """{"tool":"shell","command":"mkdir -p api_dir","reason":"Create api dir","timeoutSec":12}"""
        )
        assertTrue(jsonFallbackRes is ToolCallParseResult.Success)
        val jsonCall = (jsonFallbackRes as ToolCallParseResult.Success).toolCall
        assertEquals("mkdir -p api_dir", jsonCall.command)
        assertEquals(12L, jsonCall.timeoutSec)

        // 4) Normalized native cloud function call block
        val nativeNormalized = ToolCallParser.formatNormalizedToolCallBlock(
            ToolCall(command = "pwd", reason = "Check cwd", source = "gemini-native"),
            explanation = "Checking directory."
        )
        val nativeParsed = ToolCallParser.parse(nativeNormalized)
        assertTrue(nativeParsed is ToolCallParseResult.Success)
        assertEquals("pwd", (nativeParsed as ToolCallParseResult.Success).toolCall.command)

        // 5) Reject empty command inside fence
        val emptyFenceRes = ToolCallParser.parse("```sh-exec\n   \n```")
        assertTrue("Empty command fence must return ParseError", emptyFenceRes is ToolCallParseResult.ParseError)

        // 6) Reject multi-line chained commands with unescaped newlines unless approved
        val multiLineUnescaped = """
            ```sh-exec
            mkdir -p web
            cd web
            ```
        """.trimIndent()
        val multiLineRejected = ToolCallParser.parse(multiLineUnescaped, allowMultiLineIfApproved = false)
        assertTrue("Unescaped multi-line command must be rejected by default", multiLineRejected is ToolCallParseResult.ParseError)

        val multiLineApproved = ToolCallParser.parse(multiLineUnescaped, allowMultiLineIfApproved = true)
        assertTrue("Approved multi-line command should parse when allowMultiLineIfApproved=true", multiLineApproved is ToolCallParseResult.Success)

        // Escaped line continuation (`\\\n`) is allowed as a single logical command
        val escapedContinuation = "```sh-exec\nmkdir -p \\\n  web/assets\n```"
        val escapedRes = ToolCallParser.parse(escapedContinuation)
        assertTrue(escapedRes is ToolCallParseResult.Success)
        assertEquals("mkdir -p web/assets", (escapedRes as ToolCallParseResult.Success).toolCall.command)

        // 7) Reject multiple command blocks in one step
        val multipleBlocks = """
            ```sh-exec
            mkdir a
            ```
            ```sh-exec
            mkdir b
            ```
        """.trimIndent()
        assertTrue(ToolCallParser.parse(multipleBlocks) is ToolCallParseResult.ParseError)

        // 8) Reject unclosed fence or malformed JSON
        assertTrue(ToolCallParser.parse("```sh-exec\nmkdir broken") is ToolCallParseResult.ParseError)
        assertTrue(ToolCallParser.parse("{\"tool\":\"shell\",\"command\":") is ToolCallParseResult.ParseError)

        // 9) Verify risk classification levels (LOW, MEDIUM, HIGH)
        assertEquals(CommandRiskLevel.LOW, ToolCallParser.classifyRisk("mkdir -p web"))
        assertEquals(CommandRiskLevel.MEDIUM, ToolCallParser.classifyRisk("rm temp.txt"))
        assertEquals(CommandRiskLevel.HIGH, ToolCallParser.classifyRisk("rm -rf build_output"))
        assertEquals(CommandRiskLevel.HIGH, ToolCallParser.classifyRisk("sudo ls"))

        // 10) Verify output feedback redaction and 2000-char truncation
        val longSecretOutput = "sk-proj-1234567890abcdefghijklmnop " + "x".repeat(2500)
        val formattedFeedback = ToolCallParser.formatToolOutputForModelFeedback(
            command = "cat .env",
            cwd = "/workspace",
            exitCode = 0,
            rawOutput = longSecretOutput,
            maxChars = 2000
        )
        assertTrue("Feedback must be truncated to <= 2000 chars", formattedFeedback.length <= 2000)
        assertFalse("Feedback must redact secrets", formattedFeedback.contains("sk-proj-1234567890"))
    }

    @Test
    fun executionPipeline_quickCommand_stubEngineNotice_andCloudToolCallApprovalGate() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val shellBridge = LocalShellBridge(context)
        val cwdDir = File(shellBridge.resetSessionCwd())
        val webDir = File(cwdDir, "web")
        if (webDir.exists()) webDir.deleteRecursively()

        val localLlmManager = LocalLlmManager(context)
        val userApiKeyStore = UserApiKeyStore(context)
        val notificationHelper = NexusNotificationHelper(context)

        try {
            // 1) Test explicit Quick Command (`/quick create a folder named web`) -> labeled "Quick command", never poses as model output
            val viewModel = NexusViewModel(
                repository = null,
                shellBridge = shellBridge,
                localLlmManager = localLlmManager,
                userApiKeyStore = userApiKeyStore,
                notificationHelper = notificationHelper,
                currentUserId = "guest_local_session",
                isGuestMode = true
            )

            viewModel.submitDirective("/quick create a folder named web")
            awaitViewModelIdle(viewModel)

            assertTrue("Directory 'web' must exist in cwd after Quick Command", webDir.exists() && webDir.isDirectory)
            val entriesAfterQuick = currentEntries(viewModel)
            assertTrue(
                "Quick command must emit a Quick Command notice card, never an AI message",
                entriesAfterQuick.any { it.type == "notice" && it.noticeKind == "quick_command" && it.text.contains("Quick command", ignoreCase = true) }
            )
            assertTrue("Transcript must contain approved command card", entriesAfterQuick.any { it.type == "command" && it.command == "mkdir -p web" && it.commandStatus == "approved" })
            assertTrue("Transcript must contain output card with exitCode 0", entriesAfterQuick.any { it.type == "output" && it.command == "mkdir -p web" && it.exitCode == 0L })

            // 2) Test Unloaded Local Model: sending prompt when local model is unloaded shows "Model not loaded" error card
            userApiKeyStore.persistSelectedProviderAndModel("local", LocalLlmManager.LOCAL_LLM_CATALOG.first().id)
            pumpMainLooper(50L)
            viewModel.unloadLocalModel()
            viewModel.submitDirective("list files")
            awaitViewModelIdle(viewModel)
            val entriesAfterUnload = currentEntries(viewModel)
            val unloadedErrorNotice = entriesAfterUnload.lastOrNull { it.type == "notice" && it.noticeKind == "error" }
            assertNotNull("Unloaded local model must produce an error notice card", unloadedErrorNotice)
            assertTrue(
                "Error card must state 'Model not loaded'",
                unloadedErrorNotice!!.text.contains("Model not loaded", ignoreCase = true)
            )

            // 3) Test StubEngine when no native JNI engine is linked: returns EngineInfo(isRuntimeInstalled = false)
            EngineProvider.resetToDefault()
            assertFalse("StubEngine.isRuntimeInstalled must be false", EngineProvider.currentEngine.info().isRuntimeInstalled)

            // 4) Test Cloud Provider pipeline: medium-risk command -> pending approval -> denied -> denial turn fed back -> agent continues
            val feedbackTurnsSeenByCloud = mutableListOf<List<Pair<String, String>>>()
            val testCloudTransport = object : ProviderTransport {
                override fun streamGeminiRest(
                    modelId: String,
                    apiKey: String,
                    maxTokens: Int,
                    systemInstruction: String,
                    conversationTurns: List<Pair<String, String>>
                ): Flow<String> {
                    feedbackTurnsSeenByCloud.add(conversationTurns)
                    val lastTurnText = conversationTurns.lastOrNull()?.second.orEmpty()
                    return when {
                        lastTurnText.contains("[COMMAND_DENIED_BY_USER]") -> {
                            flowOf("Understood, skipping deletion of `obsolete.txt` as requested.")
                        }
                        lastTurnText.contains("[TOOL_EXECUTION_RESULT]") -> {
                            flowOf("Verified `cloud_web` folder creation with exit code 0.")
                        }
                        lastTurnText.contains("delete obsolete.txt") -> {
                            flowOf("```sh-exec\nrm obsolete.txt\n```")
                        }
                        else -> {
                            flowOf("```sh-exec\nmkdir -p cloud_web\n```")
                        }
                    }
                }

                override fun streamAnthropicRest(
                    modelId: String,
                    apiKey: String,
                    maxTokens: Int,
                    systemInstruction: String,
                    conversationTurns: List<Pair<String, String>>
                ): Flow<String> = flowOf()

                override fun streamOpenAiCompatibleRest(
                    provider: String,
                    endpointUrl: String,
                    modelId: String,
                    apiKey: String,
                    maxTokens: Int,
                    systemInstruction: String,
                    conversationTurns: List<Pair<String, String>>
                ): Flow<String> = flowOf()

                override fun streamLocalOnDevice(
                    modelId: String,
                    userPrompt: String,
                    currentCwd: String,
                    compactSystemPrompt: String,
                    recentCommandOutputs: List<Pair<String, String>>
                ): Flow<String> = flowOf()
            }

            userApiKeyStore.setApiKey("gemini", null, "user-test-gemini-key")
            userApiKeyStore.persistSelectedProviderAndModel("gemini", "gemini-2.5-flash")

            val cloudVm = NexusViewModel(
                repository = null,
                shellBridge = shellBridge,
                localLlmManager = localLlmManager,
                userApiKeyStore = userApiKeyStore,
                notificationHelper = notificationHelper,
                currentUserId = "test_user_cloud",
                isGuestMode = true,
                customTransport = testCloudTransport
            )

            val cloudWebDir = File(cwdDir, "cloud_web")
            if (cloudWebDir.exists()) cloudWebDir.deleteRecursively()

            cloudVm.submitDirective("create a folder named cloud_web")
            awaitViewModelIdle(cloudVm)

            assertTrue("Cloud provider tool call must create cloud_web in cwd", cloudWebDir.exists() && cloudWebDir.isDirectory)
            assertTrue(
                "Cloud provider must receive [TOOL_EXECUTION_RESULT] in step 2",
                feedbackTurnsSeenByCloud.any { turns -> turns.any { it.second.contains("[TOOL_EXECUTION_RESULT]") } }
            )

            // Test MEDIUM-risk command ("rm obsolete.txt") -> requires approval -> deny it -> verify denial turn & agent continuation
            cloudVm.submitDirective("delete obsolete.txt")
            val waitStart = System.currentTimeMillis()
            var pendingEntry: TranscriptEntry? = null
            while (System.currentTimeMillis() - waitStart < 4000L) {
                shadowOf(Looper.getMainLooper()).idle()
                pendingEntry = currentEntries(cloudVm).find { it.type == "command" && it.commandStatus == "pending" }
                if (pendingEntry != null) break
                delay(25L)
            }
            assertNotNull("Medium-risk command 'rm obsolete.txt' must pause at approval gate", pendingEntry)

            cloudVm.resolveCommandPermission(pendingEntry!!, approved = false)
            awaitViewModelIdle(cloudVm)

            val postDenyEntries = currentEntries(cloudVm)
            assertTrue(
                "Transcript must show denial notice",
                postDenyEntries.any { it.type == "notice" && it.text.contains("Command denied by user", ignoreCase = true) }
            )
            assertTrue(
                "Agent must continue after denial and acknowledge it",
                postDenyEntries.any { it.type == "agent" && it.text.contains("skipping deletion", ignoreCase = true) }
            )
        } finally {
            EngineProvider.resetToDefault()
        }
    }

    @Test
    fun guestQuota_countsOnlyCloudPrompts_andAllowsLocalModelsAndDirectShellAtZeroQuota() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val shellBridge = LocalShellBridge(context)
        val cwdDir = File(shellBridge.resetSessionCwd())
        val localLlmManager = LocalLlmManager(context)
        val userApiKeyStore = UserApiKeyStore(context)
        val notificationHelper = NexusNotificationHelper(context)

        // Register a test LocalInferenceEngine via EngineProvider seam to verify local execution at 0/5 guest quota
        val localSpec = LocalLlmManager.LOCAL_LLM_CATALOG.first()
        val ggufFile = File(localLlmManager.modelsDir, "${localSpec.id}.gguf")
        ggufFile.parentFile?.mkdirs()
        // Write valid GGUF magic header + padding so loadModel succeeds
        ggufFile.writeBytes("GGUF".toByteArray() + ByteArray(1024))

        val testNativeEngine = object : LocalInferenceEngine {
            private val _loaded = kotlinx.coroutines.flow.MutableStateFlow(false)
            override val isLoaded: kotlinx.coroutines.flow.StateFlow<Boolean> = _loaded

            override suspend fun load(path: String, params: com.example.domain.InferenceParams): Result<Unit> {
                _loaded.value = true
                return Result.success(Unit)
            }

            override fun generate(prompt: String, params: com.example.domain.InferenceParams): Flow<String> = flow {
                if (prompt.contains("[TOOL_EXECUTION_RESULT]\nCommand:")) {
                    emit("Created folder guest_local_ok.")
                } else {
                    emit("```sh-exec\nmkdir -p guest_local_ok\n```")
                }
            }

            override fun stop() {}

            override fun unload() {
                _loaded.value = false
            }

            override fun info(): com.example.domain.EngineInfo = com.example.domain.EngineInfo(
                name = "TestNativeLlamaEngine",
                version = "1.0-test",
                isRuntimeInstalled = true,
                statusMessage = "Ready"
            )
        }

        try {
            EngineProvider.currentEngine = testNativeEngine
            localLlmManager.switchActiveLocalModel(localSpec.id)
            userApiKeyStore.setApiKey("gemini", null, "user-gemini-key")

            val guestVm = NexusViewModel(
                repository = null,
                shellBridge = shellBridge,
                localLlmManager = localLlmManager,
                userApiKeyStore = userApiKeyStore,
                notificationHelper = notificationHelper,
                currentUserId = "guest_quota_test",
                isGuestMode = true
            )

            // Set guest quota to exhausted (5/5 used -> 0 remaining)
            guestVm.setGuestDirectivesUsedForTest(NexusViewModel.GUEST_MAX_DIRECTIVES)
            assertEquals(5, guestVm.guestDirectivesUsed.value)

            // 1) Cloud provider prompt at 0/5 quota must be blocked and show inline "Limit reached, sign in" card
            userApiKeyStore.persistSelectedProviderAndModel("gemini", "gemini-2.5-flash")
            shadowOf(Looper.getMainLooper()).idle()
            guestVm.submitDirective("create a folder named blocked_cloud")
            delay(40L)
            shadowOf(Looper.getMainLooper()).idle()
            val entriesAfterCloudBlock = currentEntries(guestVm)
            assertTrue(
                "Exhausted guest quota on cloud provider must emit 'Limit reached, sign in' notice card",
                entriesAfterCloudBlock.any {
                    it.type == "notice" &&
                        it.noticeKind == "guest_limit" &&
                        it.text.contains("Limit reached, sign in", ignoreCase = true)
                }
            )
            assertFalse(File(cwdDir, "blocked_cloud").exists())

            // 2) Local model prompt at 0/5 quota must NOT consume quota and MUST still work!
            val guestLocalDir = File(cwdDir, "guest_local_ok")
            if (guestLocalDir.exists()) guestLocalDir.deleteRecursively()
            userApiKeyStore.persistSelectedProviderAndModel("local", localSpec.id)
            shadowOf(Looper.getMainLooper()).idle()

            guestVm.submitDirective("create a folder named guest_local_ok")
            awaitViewModelIdle(guestVm)

            assertEquals("Local model must not increment guestDirectivesUsed", 5, guestVm.guestDirectivesUsed.value)
            assertTrue("Local model must still execute commands when guest quota is 0/5", guestLocalDir.exists() && guestLocalDir.isDirectory)

            // 3) Direct shell mode (`sh >`) at 0/5 quota must bypass LLM and execute
            val directShDir = File(cwdDir, "direct_sh_ok")
            if (directShDir.exists()) directShDir.deleteRecursively()
            guestVm.executeDirectShellCommand("mkdir -p direct_sh_ok")
            awaitViewModelIdle(guestVm)

            assertTrue("Direct shell command (sh >) must succeed at 0/5 guest quota", directShDir.exists() && directShDir.isDirectory)

            // 4) Verify cwd permission check surfaces "Grant file access" when outside app storage and All Files Access is missing
            shellBridge.hasAllFilesAccessChecker = { false }
            val validation = shellBridge.validateWorkingDirectory("/storage/emulated/0/Download")
            assertTrue("External storage path without All Files Access must return MissingAllFilesAccess", validation is CwdValidationResult.MissingAllFilesAccess)
        } finally {
            EngineProvider.resetToDefault()
            ggufFile.delete()
        }
    }

    @Test
    fun providerRouting_hitsSelectedProviderOnly_andRequiresUserKeyForCloudProviders() = runBlocking {
        val hitLog = mutableListOf<Pair<String, String>>()
        val testTransport = object : ProviderTransport {
            override fun streamGeminiRest(
                modelId: String,
                apiKey: String,
                maxTokens: Int,
                systemInstruction: String,
                conversationTurns: List<Pair<String, String>>
            ): Flow<String> {
                hitLog.add("gemini" to modelId)
                return flowOf("ok:gemini:$modelId")
            }

            override fun streamAnthropicRest(
                modelId: String,
                apiKey: String,
                maxTokens: Int,
                systemInstruction: String,
                conversationTurns: List<Pair<String, String>>
            ): Flow<String> {
                hitLog.add("anthropic" to modelId)
                return flowOf("ok:anthropic:$modelId")
            }

            override fun streamOpenAiCompatibleRest(
                provider: String,
                endpointUrl: String,
                modelId: String,
                apiKey: String,
                maxTokens: Int,
                systemInstruction: String,
                conversationTurns: List<Pair<String, String>>
            ): Flow<String> {
                hitLog.add(provider to modelId)
                return flowOf("ok:$provider:$modelId")
            }

            override fun streamLocalOnDevice(
                modelId: String,
                userPrompt: String,
                currentCwd: String,
                compactSystemPrompt: String,
                recentCommandOutputs: List<Pair<String, String>>
            ): Flow<String> {
                hitLog.add("local" to modelId)
                return flowOf("ok:local:$modelId")
            }
        }

        val providersToTest = listOf(
            Triple("gemini", "gemini-2.5-flash", "user-gemini-key"),
            Triple("anthropic", "claude-sonnet-5-5", "user-claude-key"),
            Triple("openai", "o3", "user-openai-key"),
            Triple("local", "qwen2.5-coder-1.5b-instruct", "")
        )

        val entries = listOf(
            TranscriptEntry(
                id = "u1",
                type = "user",
                text = "Hello",
                cwd = "/nexus_workspace",
                sequence = 1L
            )
        )

        for ((provider, modelId, key) in providersToTest) {
            hitLog.clear()
            val chunks = MultiPlatformAiEngine.routeWithTransport(
                provider = provider,
                modelId = modelId,
                personalApiKey = key,
                maxTokens = 512L,
                entries = entries,
                personaPrompt = "System",
                currentCwd = "/nexus_workspace",
                fallbackUserPrompt = "Hello",
                transport = testTransport
            ).toList()

            val response = chunks.joinToString("")
            assertEquals("Each request must hit exactly one provider", 1, hitLog.size)
            assertEquals("Request for $provider must hit $provider only", provider, hitLog.first().first)
            assertEquals("Request for $modelId must use exact modelId", modelId, hitLog.first().second)
            assertEquals("ok:$provider:$modelId", response)
        }

        // Legacy "fable" provider routes under "anthropic"
        hitLog.clear()
        MultiPlatformAiEngine.routeWithTransport(
            provider = "fable",
            modelId = "claude-fable-5-1",
            personalApiKey = "user-anthropic-key",
            maxTokens = 512L,
            entries = entries,
            personaPrompt = "System",
            currentCwd = "/nexus_workspace",
            fallbackUserPrompt = "Hello",
            transport = testTransport
        ).toList()
        assertEquals("anthropic", hitLog.single().first)
        assertEquals("claude-fable-5-1", hitLog.single().second)

        // Verify that cloud providers throw MissingApiKeyException when key is blank
        for (cloudProvider in listOf("gemini", "anthropic", "openai")) {
            hitLog.clear()
            try {
                MultiPlatformAiEngine.routeWithTransport(
                    provider = cloudProvider,
                    modelId = "test-model",
                    personalApiKey = "",
                    maxTokens = 512L,
                    entries = entries,
                    personaPrompt = "System",
                    currentCwd = "/nexus_workspace",
                    fallbackUserPrompt = "Hello",
                    transport = testTransport
                ).toList()
                fail("Expected MissingApiKeyException for $cloudProvider when key is blank")
            } catch (expected: MissingApiKeyException) {
                assertEquals(cloudProvider, expected.provider)
                assertTrue("Transport must not be called when API key is missing", hitLog.isEmpty())
            }
        }
    }

    @Test
    fun mockWebServer_providerModelDiscovery_errorMapping_and404AutoSwapPolicy() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val keyStore = UserApiKeyStore(context)
        keyStore.setProviderKey("gemini", "AIzaSyTestKey123")
        val server = MockWebServer()
        server.start()

        try {
            val baseUrl = server.url("/").toString().trimEnd('/')
            val repo = ProviderModelRepository(
                context = context,
                userApiKeyStore = keyStore,
                httpClient = OkHttpClient()
            ).apply {
                geminiBaseUrl = baseUrl
                anthropicBaseUrl = baseUrl
                openAiBaseUrl = baseUrl
            }

            // 1) Gemini GET /v1beta/models: strips "models/" prefix, filters by generateContent, sends x-goog-api-key header
            server.enqueue(
                MockResponse()
                    .setResponseCode(200)
                    .setBody(
                        """
                        {
                          "models": [
                            {
                              "name": "models/gemini-2.5-flash",
                              "displayName": "models/gemini-2.5-flash",
                              "supportedGenerationMethods": ["generateContent", "countTokens"]
                            },
                            {
                              "name": "models/text-embedding-004",
                              "displayName": "Text Embedding 004",
                              "supportedGenerationMethods": ["embedContent"]
                            }
                          ]
                        }
                        """.trimIndent()
                    )
            )

            val geminiRes = repo.fetchModelsForProvider("gemini", forceRefresh = true, overrideApiKey = "AIzaSyTestKey123")
            assertTrue(geminiRes.isSuccess)
            val geminiModels = geminiRes.getOrThrow()
            assertEquals("Only generateContent models must be kept", 1, geminiModels.size)
            assertEquals("models/ prefix must be stripped from ModelOption.id", "gemini-2.5-flash", geminiModels.single().id)
            assertEquals("models/ prefix must be stripped from displayName", "gemini-2.5-flash", geminiModels.single().displayName)
            assertFalse("supportsToolCalls must default to false", geminiModels.single().supportsToolCalls)

            val recordedGeminiReq = server.takeRequest()
            assertEquals("AIzaSyTestKey123", recordedGeminiReq.getHeader("x-goog-api-key"))

            // 2) Anthropic fallback seed list when offline/error: falls back to 4 unverified seeds including claude-fable-5-1
            server.enqueue(MockResponse().setResponseCode(503).setBody("""{"error":{"message":"Overloaded"}}"""))
            val anthropicFallback = repo.fetchModelsForProvider("anthropic", forceRefresh = true, overrideApiKey = "sk-ant-test")
            assertTrue(anthropicFallback.isFailure)
            server.takeRequest()
            val seeds = repo.anthropicModels.value
            assertEquals(4, seeds.size)
            assertTrue(seeds.all { it.isUnverified })
            assertTrue(seeds.any { it.id == "claude-fable-5-1" })

            // 3) OpenAI heuristic filter vs Show All toggle
            val openAiJson = """
                {
                  "data": [
                    {"id": "gpt-4o-mini"},
                    {"id": "o3-mini"},
                    {"id": "text-embedding-3-small"},
                    {"id": "whisper-1"}
                  ]
                }
            """.trimIndent()
            server.enqueue(MockResponse().setResponseCode(200).setBody(openAiJson))
            repo.setShowAllOpenAiModels(false)
            val filteredOpenAi = repo.fetchModelsForProvider("openai", forceRefresh = true, overrideApiKey = "sk-proj-test")
            assertTrue(filteredOpenAi.isSuccess)
            val filteredIds = filteredOpenAi.getOrThrow().map { it.id }
            assertEquals(listOf("gpt-4o-mini", "o3-mini"), filteredIds)
            server.takeRequest()

            repo.setShowAllOpenAiModels(true)
            assertEquals(4, repo.openAiModels.value.size)

            // 4) Amendment #2: 404 Replacement Policy — auto-swap ONLY when error message names a replacement in the refreshed list
            server.enqueue(
                MockResponse()
                    .setResponseCode(200)
                    .setBody(
                        """
                        {
                          "models": [
                            {"name": "models/gemini-2.5-flash", "supportedGenerationMethods": ["generateContent"]},
                            {"name": "models/gemini-2.5-pro", "supportedGenerationMethods": ["generateContent"]}
                          ]
                        }
                        """.trimIndent()
                    )
            )
            val namedResolution = repo.handleModelNotFound(
                provider = "gemini",
                failedModelId = "gemini-1.5-flash",
                errorBody = "Model gemini-1.5-flash is deprecated. Please use gemini-2.5-flash instead."
            )
            assertEquals("gemini-2.5-flash", namedResolution.autoSwappedModel?.id)
            server.takeRequest()

            server.enqueue(
                MockResponse()
                    .setResponseCode(200)
                    .setBody(
                        """
                        {
                          "models": [
                            {"name": "models/gemini-2.5-flash", "supportedGenerationMethods": ["generateContent"]},
                            {"name": "models/gemini-2.5-pro", "supportedGenerationMethods": ["generateContent"]}
                          ]
                        }
                        """.trimIndent()
                    )
            )
            val unnamedResolution = repo.handleModelNotFound(
                provider = "gemini",
                failedModelId = "gemini-1.5-flash",
                errorBody = "models/gemini-1.5-flash is not found for API version v1beta."
            )
            assertNull("Must NOT pick first verified model when error does not name a replacement", unnamedResolution.autoSwappedModel)
            server.takeRequest()

            // 5) Error mapping: 401/403 -> INVALID_API_KEY, 404 -> MODEL_NOT_FOUND, 429 -> RATE_LIMITED with Retry-After
            val err401 = MultiPlatformAiEngine.classifyHttpError("gemini", "gemini-2.5-flash", 401, """{"error":{"message":"API key not valid"}}""", null)
            assertEquals(com.example.domain.ProviderErrorKind.INVALID_API_KEY, err401.kind)

            val err404 = MultiPlatformAiEngine.classifyHttpError("gemini", "gemini-old", 404, """{"error":{"message":"Model gemini-old is no longer available"}}""", null)
            assertEquals(com.example.domain.ProviderErrorKind.MODEL_NOT_FOUND, err404.kind)

            val err429 = MultiPlatformAiEngine.classifyHttpError("openai", "gpt-4o", 429, """{"error":{"message":"Rate limit reached"}}""", "7")
            assertEquals(com.example.domain.ProviderErrorKind.RATE_LIMITED, err429.kind)
            assertEquals(7L, err429.retryAfterSeconds)
        } finally {
            server.shutdown()
        }
    }

    @Test
    fun mockWebServer_ggufDownloader_resumesWithRangeAndIfRange_verifiesSha256_andRejectsMismatch() = runBlocking {
        val server = MockWebServer()
        server.start()

        val tempDir = File(System.getProperty("java.io.tmpdir"), "nexus_gguf_test_${System.currentTimeMillis()}")
        tempDir.mkdirs()

        try {
            // Build a valid GGUF payload starting with 'G','G','U','F' (0x47, 0x47, 0x55, 0x46)
            val fullPayload = "GGUF".toByteArray() + ByteArray(2048) { idx -> (idx % 251).toByte() }
            val digest = MessageDigest.getInstance("SHA-256")
            val expectedSha256 = digest.digest(fullPayload).joinToString("") { "%02x".format(it) }

            val part1 = fullPayload.copyOfRange(0, 512)
            val part2 = fullPayload.copyOfRange(512, fullPayload.size)

            val targetFile = File(tempDir, "test-model.gguf")
            val partFile = File(tempDir, "test-model.gguf.part")

            // Write initial 512 bytes to .part to test resuming from a partial file
            partFile.writeBytes(part1)

            // 1) Pre-redirect HEAD response returns x-linked-etag & x-linked-size, followed by 206 Partial Content GET
            server.enqueue(
                MockResponse()
                    .setResponseCode(200)
                    .setHeader("x-linked-etag", "\"etag-gguf-v1\"")
                    .setHeader("x-linked-size", fullPayload.size.toString())
            )
            val buffer2 = Buffer().write(part2)
            server.enqueue(
                MockResponse()
                    .setResponseCode(206)
                    .setHeader("ETag", "\"etag-gguf-v1\"")
                    .setHeader("Content-Length", part2.size.toString())
                    .setHeader("Content-Range", "bytes 512-${fullPayload.size - 1}/${fullPayload.size}")
                    .setBody(buffer2)
            )

            val downloadUrl = server.url("/resolve/main/test-model.gguf").toString()
            val result = com.example.domain.ResumableGgufDownloader.downloadModelResumable(
                modelId = "test-model",
                canonicalUrl = downloadUrl,
                modelsDir = tempDir,
                expectedManifestSha256 = expectedSha256,
                expectedManifestSizeBytes = fullPayload.size.toLong(),
                hfToken = "hf_test_token_123",
                storedEtag = "",
                baseClient = OkHttpClient(),
                onProgress = { _, _ -> }
            )

            assertTrue("Resumable GGUF download should succeed: ${result.exceptionOrNull()?.message}", result.isSuccess)
            assertTrue("Final .gguf file must exist after atomic rename", targetFile.exists())
            assertFalse(".part file must be renamed/removed after completion", partFile.exists())
            assertEquals(fullPayload.size.toLong(), targetFile.length())

            val headReq = server.takeRequest()
            assertEquals("HEAD", headReq.method)
            assertEquals("Bearer hf_test_token_123", headReq.getHeader("Authorization"))

            val rangeReq = server.takeRequest()
            assertEquals("GET", rangeReq.method)
            assertEquals("bytes=512-", rangeReq.getHeader("Range"))
            assertEquals("\"etag-gguf-v1\"", rangeReq.getHeader("If-Range"))
            assertEquals("Bearer hf_test_token_123", rangeReq.getHeader("Authorization"))

            // 2) Test SHA-256 mismatch: must delete corrupt file and return failure
            val badTargetFile = File(tempDir, "bad-model.gguf")
            val badPartFile = File(tempDir, "bad-model.gguf.part")
            server.enqueue(
                MockResponse()
                    .setResponseCode(200)
                    .setHeader("x-linked-etag", "\"etag-bad\"")
                    .setHeader("x-linked-size", fullPayload.size.toString())
            )
            server.enqueue(
                MockResponse()
                    .setResponseCode(200)
                    .setHeader("Content-Length", fullPayload.size.toString())
                    .setBody(Buffer().write(fullPayload))
            )

            val badResult = com.example.domain.ResumableGgufDownloader.downloadModelResumable(
                modelId = "bad-model",
                canonicalUrl = server.url("/resolve/main/bad-model.gguf").toString(),
                modelsDir = tempDir,
                expectedManifestSha256 = "0000000000000000000000000000000000000000000000000000000000000000",
                expectedManifestSizeBytes = fullPayload.size.toLong(),
                hfToken = "",
                storedEtag = "",
                baseClient = OkHttpClient(),
                onProgress = { _, _ -> }
            )
            assertTrue("SHA-256 mismatch must fail", badResult.isFailure)
            assertFalse("Corrupt .part file must be deleted on SHA-256 mismatch", badPartFile.exists())
            assertFalse("Final file must not be created on SHA-256 mismatch", badTargetFile.exists())
        } finally {
            tempDir.deleteRecursively()
            server.shutdown()
        }
    }

    @Test
    fun recommendationEngine_scalesFrom4GbPhoneTo16GbSnapdragon8Flagship() {
        val catalog = ModelRegistry.loadModels()
        assertTrue("Catalog should include at least 15 models across 0.36B to 14B", catalog.size >= 15)

        val lowMidPhone = DeviceProfiler.buildProfileFromSpecs(
            totalRamGb = 4.0,
            availableRamGb = 1.9,
            freeStorageGb = 12.0,
            socManufacturer = "MediaTek",
            socModel = "Helio G99",
            primeCores = 0,
            bigCores = 2,
            littleCores = 6,
            maxFreqKhz = 2_200_000L,
            benchmarkCompositeScore = 42
        )

        val lowReport = RecommendationEngine.evaluateCatalog(
            deviceProfile = lowMidPhone,
            catalog = catalog,
            preset = InferencePreset.BALANCED
        )
        assertNotNull("4GB phone must still receive a compatible top pick", lowReport.topPick)
        assertTrue(
            "Top pick on 4GB phone with 1.9GB free RAM must be <= 1.7B",
            lowReport.topPick!!.entry.paramsBillions <= 1.7
        )
        val qwen14bOnLow = lowReport.allEvaluated.first { it.entry.id == "qwen2.5-coder-14b-instruct" }
        assertEquals(RecommendationBucket.NOT_RECOMMENDED, qwen14bOnLow.bucket)
        assertTrue(
            "Rejection reason must explain RAM shortfall",
            qwen14bOnLow.rejectionReason.orEmpty().contains("RAM", ignoreCase = true)
        )

        val flagship16Gb = DeviceProfiler.buildProfileFromSpecs(
            totalRamGb = 16.0,
            availableRamGb = 10.8,
            freeStorageGb = 64.0,
            socManufacturer = "Qualcomm",
            socModel = "Snapdragon 8 Gen 3",
            primeCores = 1,
            bigCores = 5,
            littleCores = 2,
            maxFreqKhz = 3_400_000L,
            benchmarkCompositeScore = 92
        )
        assertEquals(DeviceTier.ULTRA, flagship16Gb.effectiveTier)

        val ultraReport = RecommendationEngine.evaluateCatalog(
            deviceProfile = flagship16Gb,
            catalog = catalog,
            preset = InferencePreset.QUALITY
        )
        assertNotNull(ultraReport.topPick)
        assertTrue(
            "16GB ULTRA device in Quality mode should recommend a 7B–14B model",
            ultraReport.topPick!!.entry.paramsBillions >= 7.0
        )
    }

    @Test
    fun userAndAiMessageColors_satisfyWcagAaContrastInLightAndDark() {
        val lightUserContrast = wcagContrastRatio(
            LightNexusSemanticColors.onUserBubble,
            LightNexusSemanticColors.userBubble
        )
        val darkUserContrast = wcagContrastRatio(
            DarkNexusSemanticColors.onUserBubble,
            DarkNexusSemanticColors.userBubble
        )
        val lightAiContrast = wcagContrastRatio(
            LightNexusSemanticColors.aiText,
            LightNexusSemanticColors.background
        )
        val darkAiContrast = wcagContrastRatio(
            DarkNexusSemanticColors.aiText,
            DarkNexusSemanticColors.background
        )

        assertTrue("Light user bubble contrast ($lightUserContrast) must exceed WCAG AA 4.5", lightUserContrast >= 4.5)
        assertTrue("Dark user bubble contrast ($darkUserContrast) must exceed WCAG AA 4.5", darkUserContrast >= 4.5)
        assertTrue("Light AI text contrast ($lightAiContrast) must exceed WCAG AA 4.5", lightAiContrast >= 4.5)
        assertTrue("Dark AI text contrast ($darkAiContrast) must exceed WCAG AA 4.5", darkAiContrast >= 4.5)
    }

    @Test
    fun localSystemPrompt_isUnder300Tokens_andIncludesFewShotShExecExamplesAndCwd() {
        val cwd = "/data/user/0/com.aistudio.nexusagent.v5sync/files/nexus_workspace"
        val prompt = MultiPlatformAiEngine.buildCompactLocalSystemInstruction(cwd)
        val approxTokens = prompt.length / 4

        assertTrue("Local system prompt ($approxTokens tokens) must be < 300 tokens", approxTokens < 300)
        assertTrue("Local system prompt must inject real cwd", prompt.contains(cwd))
        assertTrue("Local system prompt must mention Android constraints (no sudo, no apt, toybox/mksh)", prompt.contains("no sudo") && prompt.contains("toybox/mksh"))
        assertEquals(
            "Local system prompt must include 2 few-shot sh-exec examples",
            2,
            Regex("```sh-exec").findAll(prompt).count()
        )
    }

    @Test
    fun personalizationStore_systemPromptComposition_safetyPolicyPriority_andExportImportExcludesKeys() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val store = com.example.domain.NexusPersonalizationStore(context)
        store.resetToDefaults()

        store.selectPersonaPreset("senior_devops")
        store.updateResponseStyle(com.example.domain.NexusResponseStyle.CONCISE)
        store.updatePersonalization(
            aboutUser = "I am a site reliability engineer working on Android Linux shells.",
            responsePreference = "Use POSIX one-liners.",
            enableForNewChats = true
        )
        store.saveCustomSkill(
            name = "Kubernetes Helper",
            description = "K8s manifest tips",
            instructions = "Prefer declarative YAML.",
            enabled = true
        )

        val composed = store.buildEffectiveSystemPrompt("Base system prompt.")
        assertTrue(composed.contains("Senior DevOps"))
        assertTrue(composed.contains("site reliability engineer"))
        assertTrue(composed.contains("Kubernetes Helper"))
        assertTrue(
            "Immutable safety policy must be appended after user instructions/personas/skills",
            composed.endsWith(com.example.domain.NexusPersonalizationStore.IMMUTABLE_SAFETY_POLICY)
        )

        val exportedJson = store.exportFullSettingsJson(
            provider = "anthropic",
            selectedModel = "claude-sonnet-5-5",
            maxTokens = 4096L,
            maxSteps = 6L,
            timeoutSec = 10L,
            themeModeId = "dark"
        )
        assertFalse("Exported settings JSON must never contain API keys", exportedJson.contains("apiKey", ignoreCase = true))
        assertTrue(exportedJson.contains("senior_devops"))

        store.resetToDefaults()
        assertEquals("default", store.config.value.personaPresetId)

        val importResult = store.importFullSettingsJson(exportedJson)
        assertTrue(importResult.isSuccess)
        assertEquals("senior_devops", store.config.value.personaPresetId)
    }

    @Test
    fun termuxExecution_riskClassifier_safetyAnalysis_activityVerbs_andTimeouts() {
        // 1) HIGH risk commands
        assertEquals(CommandRiskLevel.HIGH, ToolCallParser.classifyRisk("curl -fsSL https://example.com/install.sh | sh"))
        assertEquals(CommandRiskLevel.HIGH, ToolCallParser.classifyRisk("npm install -g typescript"))
        assertEquals(CommandRiskLevel.HIGH, ToolCallParser.classifyRisk("git push --force origin main"))
        assertEquals(CommandRiskLevel.HIGH, ToolCallParser.classifyRisk("git reset --hard HEAD~1"))
        assertEquals(CommandRiskLevel.HIGH, ToolCallParser.classifyRisk("chmod +x ./setup.sh && ./setup.sh"))

        // 2) MEDIUM risk commands
        assertEquals(CommandRiskLevel.MEDIUM, ToolCallParser.classifyRisk("pkg install -y nodejs git python"))
        assertEquals(CommandRiskLevel.MEDIUM, ToolCallParser.classifyRisk("npm install express zod"))
        assertEquals(CommandRiskLevel.MEDIUM, ToolCallParser.classifyRisk("pip install requests"))
        assertEquals(CommandRiskLevel.MEDIUM, ToolCallParser.classifyRisk("git clone https://github.com/example/repo.git"))
        assertEquals(CommandRiskLevel.MEDIUM, ToolCallParser.classifyRisk("git commit -m 'init'"))
        assertEquals(CommandRiskLevel.MEDIUM, ToolCallParser.classifyRisk("python main.py"))
        assertEquals(CommandRiskLevel.MEDIUM, ToolCallParser.classifyRisk("node server.js"))

        // 3) LOW risk read-only commands
        assertEquals(CommandRiskLevel.LOW, ToolCallParser.classifyRisk("git status"))
        assertEquals(CommandRiskLevel.LOW, ToolCallParser.classifyRisk("git diff"))
        assertEquals(CommandRiskLevel.LOW, ToolCallParser.classifyRisk("git log -n 5"))
        assertEquals(CommandRiskLevel.LOW, ToolCallParser.classifyRisk("node -v"))
        assertEquals(CommandRiskLevel.LOW, ToolCallParser.classifyRisk("npm -v"))
        assertEquals(CommandRiskLevel.LOW, ToolCallParser.classifyRisk("python --version"))
        assertEquals(CommandRiskLevel.LOW, ToolCallParser.classifyRisk("pip list"))
        assertEquals(CommandRiskLevel.LOW, ToolCallParser.classifyRisk("which git"))

        // 4) Safety analysis metadata for approval card (package names, registry hosts, install scripts)
        val npmSafety = ToolCallParser.analyzeCommandSafety("npm install express axios")
        assertTrue(npmSafety.packageNames.containsAll(listOf("express", "axios")))
        assertTrue(npmSafety.registryHosts.contains("registry.npmjs.org"))
        assertTrue(npmSafety.runsInstallScripts)

        val npmIgnoreScripts = ToolCallParser.analyzeCommandSafety("npm install --ignore-scripts express")
        assertFalse(npmIgnoreScripts.runsInstallScripts)

        val pkgSafety = ToolCallParser.analyzeCommandSafety("pkg update -y && pkg install -y nodejs git python")
        assertTrue(pkgSafety.packageNames.containsAll(listOf("nodejs", "git", "python")))
        assertTrue(pkgSafety.registryHosts.contains("packages.termux.dev"))

        // 5) Activity-row verbs
        assertEquals("Installing…", ToolCallParser.activityVerbForCommand("npm install express"))
        assertEquals("Running git…", ToolCallParser.activityVerbForCommand("git status"))
        assertEquals("Executing Python…", ToolCallParser.activityVerbForCommand("python3 script.py"))
        assertEquals("Running Node…", ToolCallParser.activityVerbForCommand("node index.js"))

        // 6) Execution timeouts (600s for installs/builds, 120s default)
        assertEquals(600L, com.example.domain.ExecutionTimeouts.recommendedTimeoutSec("pkg install -y nodejs git"))
        assertEquals(600L, com.example.domain.ExecutionTimeouts.recommendedTimeoutSec("npm install express"))
        assertEquals(120L, com.example.domain.ExecutionTimeouts.recommendedTimeoutSec("git status"))

        // 7) Middle-ellipsis path formatter
        val longPath = "/data/user/0/com.aistudio.nexusagent.v5sync/files/nexus_workspace"
        val shortened = com.example.domain.NexusToolAndRedactor.shortenPathMiddle(longPath, 32)
        assertTrue(shortened.contains("…"))
        assertTrue(shortened.endsWith("nexus_workspace"))
    }
}

